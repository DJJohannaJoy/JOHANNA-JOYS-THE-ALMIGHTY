# -*- coding: utf-8 -*-
"""UTF-8 list-file wrapper; audfprint upstream sources are copied unmodified."""
from __future__ import annotations
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
UPSTREAM = ROOT / "engine" / "audfprint"
sys.path.insert(0, str(UPSTREAM))
import audfprint  # noqa: E402


def utf8_iterator(filelist, wavdir, wavext, listflag):
    if not listflag:
        for f in filelist:
            yield str(Path(wavdir) / (f + wavext)) if wavdir else f + wavext
    else:
        for listfilename in filelist:
            with open(listfilename, "r", encoding="utf-8-sig") as stream:
                for raw in stream:
                    f = raw.rstrip("\r\n")
                    if f:
                        yield str(Path(wavdir) / (f + wavext)) if wavdir else f + wavext


audfprint.filename_list_iterator = utf8_iterator
if __name__ == "__main__":
    audfprint.main([str(UPSTREAM / "audfprint.py")] + sys.argv[1:])
