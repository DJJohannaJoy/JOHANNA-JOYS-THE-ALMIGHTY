# -*- coding: utf-8 -*-
"""Local mix-id Shazam adapter.
The local offline engine is audfprint. The separate TrackID API service is not used.
"""
from __future__ import annotations
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
from pathlib import Path
from typing import Callable
import scanner_core as C

ROOT = Path(__file__).resolve().parent
MIX_COPY = ROOT / 'engine' / 'mix-id'


def locate_mixid(preferred='') -> Path | None:
    """Engine is bundled into the SET SCANNER directory after first-run setup."""
    if (MIX_COPY / 'cli.mjs').is_file() and (MIX_COPY / 'lib' / 'audio.mjs').is_file():
        return MIX_COPY
    return None


def mixid_ready(cfg):
    return bool((ROOT / 'tools' / 'node' / 'node.exe').is_file() and
                locate_mixid() is not None and
                (MIX_COPY / 'node_modules' / 'shazam-api').is_dir())


def ensure_mixid_copy(cfg: dict, log: Callable[[str],None]) -> Path:
    if not mixid_ready(cfg):
        raise RuntimeError('mix-id ist nicht eingerichtet. Bitte den SET SCANNER mit 2_SET_SCANNER_STARTEN.bat starten, damit alle Engines automatisch installiert werden.')
    target = MIX_COPY
    p = target/'lib'/'audio.mjs'
    s = p.read_text(encoding='utf-8')
    edited = s.replace('`which ${cmd}`','`where.exe ${cmd}`').replace('2>/dev/null','2>nul')
    if edited != s:
        p.write_text(edited,encoding='utf-8')
    return target


def parse_hms(value) -> float:
    if isinstance(value,(int,float)):
        return float(value)
    parts = str(value or '').strip(' []').split(':')
    try:
        s = 0.
        for part in parts:
            s = s*60 + float(part)
        return s
    except ValueError:
        return 0.


def parse_mixid_json(data: str | dict) -> list[dict]:
    payload = json.loads(data) if isinstance(data,str) else data
    result = []
    for tr in payload.get('tracks',[]):
        if not isinstance(tr,dict) or not tr.get('title'):
            continue
        t = tr.get('position_sec',None)
        if t is None:
            t = parse_hms(tr.get('timestamp','0'))
        result.append({'time':float(t),'artist':str(tr.get('artist') or '').strip(),
                       'title':str(tr['title']).strip(),'source':'mix-id',
                       'confidence':'ungeprüfter Online-Treffer'})
    return result


def run_mixid(mix: Path, cfg: dict, env: dict, log, cancel: threading.Event):
    project = ensure_mixid_copy(cfg,log)
    node = str(ROOT / 'tools' / 'node' / 'node.exe')
    if not Path(node).is_file():
        raise RuntimeError('Lokales Node.js fehlt. Bitte SET SCANNER Starter erneut ausführen.')
    with tempfile.TemporaryDirectory(prefix='set-scanner-mixid-') as folder:
        folder = Path(folder)
        # mix-id always writes beside the input. Avoid extra files beside the user's original set.
        linked = folder/('set'+mix.suffix.lower())
        try:
            os.link(mix,linked)
        except OSError:
            shutil.copy2(mix,linked)
        code, output = C.run_cmd([node,str(project/'cli.mjs'),str(linked),'--step','60'],
                                 env,cwd=project,cancel=cancel,log=log,echo=True)
        result_path = folder/'set_tracklist.json'
        hits = parse_mixid_json(result_path.read_text(encoding='utf-8')) if result_path.is_file() else []
        if code != 0:
            return hits, f'mix-id beendet mit Code {code}. Die Tracklist ist möglicherweise unvollständig.'
        if not result_path.is_file():
            return hits, 'mix-id hat keine JSON-Ergebnisdatei erzeugt (Abbruch, Rate-Limit oder keine Treffer).'
        return hits, ''

def normalize_title(x):
    return re.sub(r'[^a-z0-9]+','',str(x).lower())


def merge_results(offline, mixid, shazam):
    """Do not turn all low-quality candidates into 'confirmed' tracks.
    Keep separate plays if > 150s apart; cross-source matches add evidence.
    """
    sources=[]
    for h in offline:
        sources.append({'time':float(h['time']),'title':str(h['title']),
                        'artist':'','source':'Offline',
                        'confidence':h.get('confidence','ungeprüft')})
    sources.extend(mixid)
    for h in shazam:
        sources.append({'time':float(h['time']),'title':h.get('title',''),
                        'artist':h.get('artist',''),'source':'ShazamIO',
                        'confidence':h.get('confidence','Online-Stichprobe')})
    records=[]
    for h in sorted(sources,key=lambda x:x['time']):
        if not h['title']:continue
        key=normalize_title(h['title'])
        candidate=next((x for x in records if normalize_title(x['title'])==key
                        and abs(x['time']-h['time'])<=150),None)
        if candidate:
            candidate['sources']=sorted(set(candidate['sources']+[h['source']]))
            if h.get('artist') and not candidate['artist']:
                candidate['artist']=h['artist']
            candidate['time']=min(candidate['time'],h['time'])
            candidate['confidence']='mehrere Engines' if len(candidate['sources'])>1 else candidate['confidence']
        else:
            records.append({'time':h['time'],'artist':h.get('artist',''),
                            'title':h['title'],'sources':[h['source']],
                            'confidence':h['confidence']})
    return sorted(records,key=lambda x:x['time'])


def merged_report(mix:Path,duration:float,offline,weak,mixid,shazam,statuses,errors):
    rec=merge_results(offline,mixid,shazam)
    lines=['SET SCANNER v0.5 | GEMEINSAME TRACKLIST','='*72,
           f'Datei: {mix}',f'Dauer: {C.hhmmss(duration)}',
           f'Erstellt: {C.stamp()}','', 'ENGINE-STATUS', '-'*72]
    for k,s in statuses.items():lines.append(f'{k}: {s}')
    lines+=['','TRACKS / KANDIDATEN (Zeit = Näherung, bitte nachhören)','-'*72]
    if not rec:lines+=['Keine ausreichend sicheren Ergebnisse.']
    for r in rec:
        ident=(r['artist']+' – ' if r['artist'] else '') + r['title']
        lines.append(f"{C.hhmmss(r['time'])} | {ident} | {' + '.join(r['sources'])} | {r['confidence']}")
    lines+=['','UNSICHERE OFFLINE-KANDIDATEN (nicht automatisch bestätigt)','-'*72]
    lines += [f"{C.hhmmss(x.get('first_detection',0))} | {x['title']} | {x['score']} Hashes" for x in weak[:80]] or ['Keine']
    lines+=['','HINWEISE','-'*72,
             'mix-id nutzt bereits Shazam, ist keine zusätzliche Offline-Engine.',
             'ShazamIO prüft nur verbleibende Stichproben. Kein Key erforderlich, aber Internet notwendig.',
             'Die Zeitmarken sind Erkennungspositionen/Schätzungen, nicht exakt ermittelte Trackstarts.',
             'Auch ein online erkannter Titel ist nicht automatisch sicher.',
             'Originaldateien und Rekordbox-Bibliothek bleiben unverändert.']
    if errors:lines+=['','FEHLER / GRENZEN','-'*72,*errors]
    C.OUTPUT.mkdir(exist_ok=True,parents=True)
    base=re.sub(r'[^\w. -]+','_',mix.stem).strip()[:60] or 'Set'
    output=C.OUTPUT/(base+'_Tracklist_'+__import__('datetime').datetime.now().strftime('%Y%m%d_%H%M%S')+'.txt')
    output.write_text('\n'.join(lines)+'\n',encoding='utf-8-sig')
    return output,rec
