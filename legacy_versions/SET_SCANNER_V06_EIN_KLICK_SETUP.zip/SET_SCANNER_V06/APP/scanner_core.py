#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SET SCANNER shared core | Windows | Local audfprint + optional ShazamIO.
The original audio files remain unchanged. This is a prototype, not a certified
identification system: cross-check every result before publishing tracklists.
"""
from __future__ import annotations

import asyncio
import datetime as dt
import json
import os
from pathlib import Path
import queue
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
from dataclasses import dataclass, asdict

APP = Path(__file__).resolve().parent
DATA = APP / "Datenbank"
OUTPUT = APP / "Ergebnisse"
LOGS = APP / "Protokolle"
VENDOR = APP / "engine" / "audfprint"
DB = DATA / "musik.pklz"
CONFIG_FILE = APP / "einstellungen.json"
EXTS = {".mp3", ".wav", ".flac", ".aiff", ".aif", ".m4a", ".ogg", ".opus", ".wma"}
AUDIOFILETYPES = "*.mp3 *.wav *.flac *.aiff *.aif *.m4a *.ogg *.opus *.wma"
DEFAULT_LIBRARY = r"I:\Musik\TECHNO & HARDTECHNO"
DEFAULT_AUDIO = Path.home() / "Downloads"

SPEEDS = [1.00, 0.94, 1.06, 0.97, 1.03, 0.90, 1.10,
          0.92, 1.08, 0.96, 1.04, 0.98, 1.02,
          0.91, 1.09, 0.93, 1.07, 0.95, 1.05, 0.99, 1.01]
SEGMENT_SECONDS = 30
MIN_SCORE = 45
STRONG_SCORE = 150
CONFIRM_GAP_SECONDS = 105
DEFAULT_MAX_SHAZAM = 50

RANGE_RE = re.compile(
    r"^Matched\s+(?P<support>[\d.]+)\s+s starting at\s+(?P<qstart>[\d.]+)\s+s in\s+"
    r"(?P<query>.*?)\s+to time\s+(?P<refstart>[\d.]+)\s+s in\s+"
    r"(?P<ref>.*?)\s+with\s+(?P<count>\d+)\s+of\s+", re.I)
SIMPLE_RE = re.compile(
    r"^Matched\s+(?P<query>.*?)\s+[\d.]+\s+sec\s+\d+\s+raw hashes\s+as\s+"
    r"(?P<ref>.*?)\s+at\s+(?P<refstart>[\d.]+)\s+s with\s+(?P<count>\d+)\s+of", re.I)
SEGMENT_RE = re.compile(r"part-(\d{4,})", re.I)


def stamp():
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def hhmmss(seconds: float) -> str:
    s = int(max(0, round(seconds)))
    return f"{s // 3600:02}:{(s // 60) % 60:02}:{s % 60:02}"


def read_config() -> dict:
    defaults = {"library": DEFAULT_LIBRARY, "shazam": True, "max_shazam": DEFAULT_MAX_SHAZAM,
                "tempo_pitch": False, "ffmpeg_dir": "", "audfprint_source": ""}
    try:
        result = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        if isinstance(result, dict):
            defaults.update(result)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass
    return defaults


def save_config(cfg: dict):
    CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def locate_ffmpeg(cfg: dict) -> str:
    """Bundled FFmpeg only. First-start bootstrap installs it into this folder."""
    path = APP / "tools" / "ffmpeg"
    if (path / "ffmpeg.exe").is_file() and (path / "ffprobe.exe").is_file():
        return str(path)
    return ""


def env_with_ffmpeg(folder: str) -> dict:
    env = os.environ.copy()
    dirs = [str(APP / "tools" / "node"), str(APP / "tools" / "ffmpeg")]
    if folder:
        dirs.insert(0, str(folder))
    env["PATH"] = os.pathsep.join(dirs) + os.pathsep + env.get("PATH", "")
    env["PYTHONIOENCODING"] = "utf-8"
    return env


def locate_source(cfg: dict) -> Path | None:
    """Never make the user search for any engine files."""
    if all((VENDOR / name).is_file() for name in
           ("audfprint.py", "audfprint_analyze.py", "audfprint_match.py", "audio_read.py", "hash_table.py", "stft.py")):
        return VENDOR
    return None


def install_engine(cfg: dict, log) -> Path:
    src = locate_source(cfg)
    if src is None:
        raise RuntimeError("Offline-Engine fehlt. Bitte 2_SET_SCANNER_STARTEN.bat erneut starten; diese richtet alle Komponenten automatisch ein.")
    return src


def run_cmd(argv: list[str], env: dict, cwd: Path | None = None, log=None,
            cancel: threading.Event | None = None, echo: bool = False) -> tuple[int, str]:
    """Read stdout+stderr incrementally, allow cancellation, avoid shell=True."""
    kwargs = dict(cwd=str(cwd or APP), env=env, stdout=subprocess.PIPE,
                  stderr=subprocess.STDOUT, text=True, errors="replace", bufsize=1)
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
    p = subprocess.Popen(argv, **kwargs)
    lines = []
    assert p.stdout is not None
    try:
        for line in p.stdout:
            lines.append(line)
            if echo and log:
                log(line.rstrip("\n"))
            if cancel is not None and cancel.is_set():
                p.terminate()
                raise RuntimeError("Vorgang vom Benutzer abgebrochen.")
        code = p.wait()
    finally:
        p.stdout.close()
        if p.poll() is None:
            p.kill()
            p.wait()
    return code, "".join(lines)


def get_duration(path: Path, env: dict) -> float:
    tool = shutil.which("ffprobe", path=env.get("PATH", ""))
    if tool:
        code, result = run_cmd([tool, "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(path)], env)
        if code == 0:
            try:
                return float(result.strip().splitlines()[-1])
            except (ValueError, IndexError):
                pass
    raise RuntimeError("ffprobe.exe wurde nicht gefunden oder konnte die Audio-Länge nicht lesen.")


def audio_files(directory: Path) -> list[Path]:
    return sorted((p for p in directory.rglob("*") if p.is_file() and p.suffix.lower() in EXTS), key=lambda p: str(p).casefold())


def write_utf8_list(path: Path, values):
    # The wrapper makes audfprint's --list accept UTF-8 even on German Windows.
    path.write_text("".join(str(v) + "\n" for v in values), encoding="utf-8")


def build_database(cfg: dict, log, cancel: threading.Event):
    DATA.mkdir(parents=True, exist_ok=True)
    src = install_engine(cfg, log)
    folder = Path(cfg["library"])
    if not folder.is_dir():
        raise RuntimeError(f"Musikordner nicht vorhanden: {folder}")
    tracks = audio_files(folder)
    if not tracks:
        raise RuntimeError(f"Keine Musikdateien im ausgewählten Ordner: {folder}")
    log(f"Datenbankaufbau: {len(tracks)} Musikdateien in {folder}")
    if len(tracks) > 2500:
        log("HINWEIS: Große Datenbank – Erstellung und spätere Suche brauchen viel RAM/Platz. Zunächst lieber einen kleineren Unterordner wählen.")
    env = env_with_ffmpeg(cfg["ffmpeg_dir"])
    list_file = DATA/"bibliothek_liste.txt"
    tmp_db = DATA/"musik_neu.pklz"
    write_utf8_list(list_file, tracks)
    if tmp_db.exists():
        tmp_db.unlink()
    cmd = [sys.executable, str(APP/"audfprint_utf8.py"), "new", "--dbase", str(tmp_db),
           "--maxtimebits", "16", "--continue-on-error", "--list", str(list_file)]
    code, output = run_cmd(cmd, env, src, log=log, cancel=cancel, echo=True)
    if code != 0 or not tmp_db.is_file():
        raise RuntimeError(f"audfprint konnte die Datenbank nicht erstellen (Code {code}). Letzte Ausgabe:\n{output[-1800:]}")
    tmp_db.replace(DB)
    manifest = {"library": str(folder), "file_count": len(tracks), "created": stamp(), "files": [str(f) for f in tracks]}
    (DATA/"bibliothek.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"Datenbank gespeichert: {DB} | {len(tracks)} Dateien")


@dataclass
class OfflineHit:
    song: str
    time: float
    score: int
    factor: float
    kind: str
    ref_time: float
    query_start: float
    segment: str
    support: float


def parse_matches(output: str, factor: float, kind: str) -> list[OfflineHit]:
    hits = []
    for row in output.splitlines():
        m = RANGE_RE.search(row)
        if m:
            d = m.groupdict()
            seg = SEGMENT_RE.search(d["query"])
            if not seg:
                continue
            segment_number = int(seg.group(1))
            qstart = float(d["qstart"])
            refstart = float(d["refstart"])
            duration = float(d["support"])
            if qstart < 0 or qstart > SEGMENT_SECONDS + 3:
                continue
            # This is only an approximation: some remix/transition edits break time alignment.
            set_time = (segment_number * SEGMENT_SECONDS + qstart) * factor
            hits.append(OfflineHit(d["ref"].strip(), max(0., set_time), int(d["count"]), factor,
                                   kind, refstart, qstart, d["query"], duration))
        else:
            m2 = SIMPLE_RE.search(row)
            if m2:
                d = m2.groupdict()
                seg = SEGMENT_RE.search(d["query"])
                if not seg:
                    continue
                set_time = int(seg.group(1)) * SEGMENT_SECONDS * factor
                hits.append(OfflineHit(d["ref"].strip(), set_time, int(d["count"]), factor,
                                       kind, float(d["refstart"]), 0, d["query"], 0))
    return hits


def grouped_hits(hits: list[OfflineHit], total_duration: float):
    # Keep the strongest variant for each song in each 30-s location; variants alone
    # are *not* independent confirmation.
    per_slot: dict[tuple[str,int], OfflineHit] = {}
    for h in hits:
        if h.score < MIN_SCORE:
            continue
        slot = int(h.time // SEGMENT_SECONDS)
        key = (h.song.casefold(), slot)
        if key not in per_slot or h.score > per_slot[key].score:
            per_slot[key] = h
    songs: dict[str,list[OfflineHit]] = {}
    for h in per_slot.values():
        songs.setdefault(h.song, []).append(h)
    accepted = []
    rejected = []
    for song, item in songs.items():
        item.sort(key=lambda h: h.time)
        group = []
        groups = []
        for h in item:
            if group and h.time - group[-1].time > CONFIRM_GAP_SECONDS:
                groups.append(group)
                group = []
            group.append(h)
        if group:
            groups.append(group)
        for g in groups:
            maximum = max(h.score for h in g)
            confident = maximum >= STRONG_SCORE or len(g) >= 2
            best = max(g, key=lambda h: h.score)
            # Estimate song start based on track-time alignment; approximate only.
            estimated_start = max(0., best.time - best.ref_time * best.factor)
            record = {"title": Path(song).stem, "full_path": song,
                      "time": min(total_duration, estimated_start),
                      "first_detection": min(h.time for h in g),
                      "last_detection": max(h.time for h in g),
                      "score": maximum, "samples": len(g),
                      "factor": best.factor, "mode": best.kind,
                      "source": "offline", "confidence": "hoch" if confident else "unsicher"}
            (accepted if confident else rejected).append(record)
    accepted.sort(key=lambda x: x["time"])
    rejected.sort(key=lambda x: x["time"])
    return accepted, rejected


def mode_args(kind: str, factor: float) -> str:
    if kind == "tempo":
        return f"atempo={factor:.5f}"
    # Simulates DJ speed changes *without* key lock (pitch shifts too).
    return f"aresample=44100,asetrate={round(44100*factor)},aresample=11025"


def scan_offline(mix: Path, cfg: dict, duration: float, log, cancel: threading.Event):
    env = env_with_ffmpeg(cfg["ffmpeg_dir"])
    ffmpeg = shutil.which("ffmpeg", path=env["PATH"])
    if not ffmpeg:
        raise RuntimeError("ffmpeg.exe ist nicht verfügbar.")
    if not DB.is_file():
        raise RuntimeError("Offline-Datenbank ist nicht vorhanden. Bitte einmal 'Datenbank aufbauen' verwenden.")
    modes = [("tempo", f) for f in SPEEDS]
    if cfg.get("tempo_pitch"):
        modes += [("pitch", f) for f in SPEEDS if abs(f - 1.0) > 1e-6]
    all_hits = []
    errors = []
    with tempfile.TemporaryDirectory(prefix="set-scanner-") as tmp:
        directory = Path(tmp)
        for i, (kind, factor) in enumerate(modes, 1):
            if cancel.is_set():
                raise RuntimeError("Scan wurde abgebrochen.")
            log(f"Offline {i}/{len(modes)}: {kind} | Tempofaktor {factor:.2f}")
            files_dir = directory/"segmente"
            files_dir.mkdir(exist_ok=True)
            for old in files_dir.glob("part-*.*"):
                old.unlink()
            ffargs = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(mix),
                      "-map", "0:a:0", "-vn", "-af", mode_args(kind, factor),
                      "-ac", "1", "-ar", "11025", "-c:a", "pcm_s16le", "-f", "segment",
                      "-segment_time", str(SEGMENT_SECONDS), "-reset_timestamps", "1",
                      str(files_dir/"part-%04d.wav")]
            code, msg = run_cmd(ffargs, env, cancel=cancel)
            if code != 0:
                errors.append(f"ffmpeg {kind}/{factor}: {msg[-500:]}")
                log("  Warnung: Audio-Segmentierung fehlgeschlagen.")
                continue
            pieces = sorted(p for p in files_dir.glob("part-*.wav") if p.stat().st_size > 20000)
            if not pieces:
                errors.append(f"Keine Segmente bei {kind}/{factor}")
                continue
            filelist = directory/"query.txt"
            write_utf8_list(filelist, pieces)
            args = [sys.executable, str(APP/"audfprint_utf8.py"), "match", "--dbase", str(DB),
                    "--exact-count", "--find-time-range", "--max-matches", "1", "--min-count", str(MIN_SCORE),
                    "--list", str(filelist)]
            code, result = run_cmd(args, env, cwd=VENDOR, cancel=cancel)
            if code != 0:
                errors.append(f"audfprint {kind}/{factor}: {result[-500:]}")
                log("  Warnung: audfprint ist bei dieser Tempo-Variante fehlgeschlagen.")
            else:
                this = parse_matches(result, factor, kind)
                all_hits.extend(this)
                log(f"  {len(pieces)} Segmente, {len(this)} Trefferkandidaten")
    accepted, rejected = grouped_hits(all_hits, duration)
    log(f"Offline beendet: {len(accepted)} bestätigte Kandidaten, {len(rejected)} unsichere Kandidaten.")
    return accepted, rejected, errors


def unknown_probe_times(duration: float, confirmed: list[dict], limit: int) -> list[float]:
    """Choose spaced query points; avoid regions with confirmed offline hits."""
    # A match is centered near the timestamp at which the detection was confirmed,
    # not necessarily the estimated song start.
    known = [(max(0, x["first_detection"]-45), min(duration, x["last_detection"]+65)) for x in confirmed]
    probes = []
    step = max(45.0, duration / max(1, limit))
    t = 12.0
    while t + 12 < duration:
        if not any(a <= t <= b for a,b in known):
            probes.append(t)
        t += step
    return probes[:limit]


async def shazam_probes(mix: Path, points: list[float], cfg: dict, log, cancel: threading.Event):
    try:
        from shazamio import Shazam
    except ImportError:
        log("ShazamIO fehlt. Offline-Ergebnis bleibt erhalten; bitte Setup erneut ausführen.")
        return [], ["ShazamIO ist nicht installiert"]
    env = env_with_ffmpeg(cfg["ffmpeg_dir"])
    ffmpeg = shutil.which("ffmpeg", path=env["PATH"])
    results, errors = [], []
    async with Shazam() as client:
        with tempfile.TemporaryDirectory(prefix="set-shazam-") as tmp:
            tmp = Path(tmp)
            for i, t in enumerate(points, 1):
                if cancel.is_set():
                    raise RuntimeError("Scan wurde abgebrochen.")
                chunk = tmp / "sample.wav"
                args = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-ss", str(t),
                        "-i", str(mix), "-t", "12", "-map", "0:a:0", "-vn", "-ac", "1",
                        "-ar", "16000", "-c:a", "pcm_s16le", str(chunk)]
                code, msg = await asyncio.to_thread(run_cmd, args, env, cancel=cancel)
                if code != 0 or not chunk.is_file():
                    errors.append(f"Shazam-Ausschnitt {hhmmss(t)} konnte nicht gelesen werden: {msg[-200:]}")
                    continue
                try:
                    response = await asyncio.wait_for(client.recognize(str(chunk)), timeout=35)
                    track = response.get("track") if isinstance(response, dict) else None
                    if isinstance(track, dict) and track.get("title"):
                        results.append({"title": str(track.get("title", "")).strip(),
                                        "artist": str(track.get("subtitle", "")).strip(),
                                        "time": t, "source": "shazam", "confidence": "vorläufig",
                                        "url": str(track.get("url", ""))})
                        log(f"Shazam {i}/{len(points)} {hhmmss(t)}: {track.get('subtitle','')} - {track.get('title')}")
                    else:
                        log(f"Shazam {i}/{len(points)} {hhmmss(t)}: kein Treffer")
                except Exception as exc:
                    errors.append(f"Shazam {hhmmss(t)}: {type(exc).__name__}: {exc}")
                    log(f"Shazam {i}/{len(points)} {hhmmss(t)}: Fehler (Details im Ergebnis)")
                await asyncio.sleep(0.5)
    # Independent observations of the same recording at nearby positions support a stronger claim.
    for a in results:
        if any(b is not a and b["title"].casefold()==a["title"].casefold()
               and b["artist"].casefold()==a["artist"].casefold()
               and abs(b["time"]-a["time"]) <= 250 for b in results):
            a["confidence"] = "mehrfach erkannt"
    return results, errors


def consolidate_shazam(observations: list[dict]) -> list[dict]:
    """One tracklist entry per contiguous cluster; separate later repeats."""
    result: list[dict] = []
    for obs in sorted(observations, key=lambda r: r["time"]):
        key = (obs["artist"].casefold(), obs["title"].casefold())
        previous = next((r for r in reversed(result)
                         if (r["artist"].casefold(), r["title"].casefold()) == key
                         and obs["time"] - r["last_seen"] < 360), None)
        if previous:
            previous["last_seen"] = obs["time"]
            previous["samples"] += 1
            if previous["samples"] > 1:
                previous["confidence"] = "mehrfach erkannt"
        else:
            item = dict(obs)
            item["last_seen"] = obs["time"]
            item["samples"] = 1
            result.append(item)
    return sorted(result, key=lambda r: r["time"])


def final_report(mix: Path, duration: float, offline, weak, shazam, errors, cfg):
    lines = ["SET SCANNER | TRACKLIST", "="*70, f"Set: {mix}",
             f"Länge: {hhmmss(duration)}", f"Erstellt: {stamp()}",
             f"Offline-Datenbank: {DB}",
             f"Onlinesuche: {'Shazam (inoffiziell)' if cfg['shazam'] else 'deaktiviert'}", "",
             "ERKANNTE TRACKS (vor Veröffentlichung anhören und prüfen)", "-"*70]
    combined = []
    for x in offline:
        combined.append((x["time"], f"{hhmmss(x['time'])} | {x['title']} | OFFLINE | {x['confidence']} | {x['score']} Hashes, {x['samples']} Fenster, Tempofaktor {x['factor']:.2f}, {x['mode']}"))
    for x in consolidate_shazam(shazam):
        combined.append((x["time"], f"{hhmmss(x['time'])} | {x['artist']} - {x['title']} | SHAZAM | {x['confidence']} ({x['samples']} Abfragen) | Zeitpunkt der ersten Abfrage, nicht exakter Trackbeginn"))
    if combined:
        lines.extend(line for _, line in sorted(combined, key=lambda x: x[0]))
    else:
        lines.append("Keine ausreichend sicheren Treffer. Das ist kein Beweis, dass die Musik nicht vorhanden ist.")
    lines += ["", "UNSICHERE OFFLINE-KANDIDATEN (nicht in die Tracklist übernehmen)", "-"*70]
    if weak:
        for x in weak[:100]:
            lines.append(f"{hhmmss(x['first_detection'])} | {x['title']} | {x['score']} Hashes, {x['samples']} Fenster")
        if len(weak) > 100:
            lines.append(f"... weitere {len(weak)-100} Kandidaten ausgeblendet")
    else:
        lines.append("Keine")
    lines += ["", "METHODIK / GRENZEN", "-"*70,
              "Offline: audfprint, Tempoanpassungen in 1-%-Schritten zwischen -10 % und +10 %.",
              "Tempo-Korrektur über ffmpeg/atempo; optional auch Pitch-Korrektur ohne Key-Lock.",
              "Bestätigte Offline-Treffer: mindestens 2 Zeitfenster oder ein sehr starker Einzeltreffer.",
              "Zeitpunkte sind Schätzungen; Übergänge, Remixe, Key-Lock und BPM-Variationen können Abweichungen verursachen.",
              "Shazam: nur für Stichproben unbekannter Bereiche, über eine inoffizielle Online-Schnittstelle.",
              "Shazam-Zeitstempel markieren die gescannte Stelle und NICHT den exakten Titelanfang.",
              "Auch mehrfach erkannte Tracks können falsch sein. Ergebnisse vor Veröffentlichung prüfen.", ""]
    if errors:
        lines += ["FEHLER / HINWEISE", "-"*70, *errors[:80]]
    OUTPUT.mkdir(parents=True, exist_ok=True)
    base = re.sub(r'[^\w. -]+', '_', mix.stem, flags=re.UNICODE).strip()[:70] or "Mix"
    filename = f"{base}_Tracklist_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    report = OUTPUT/filename
    report.write_text("\n".join(lines)+"\n", encoding="utf-8-sig")
    return report


class GUI:
    def __init__(self):
        for path in (DATA, OUTPUT, LOGS): path.mkdir(parents=True, exist_ok=True)
        self.cfg = read_config()
        self.root = tk.Tk()
        self.root.title("SET SCANNER 0.1  |  Offline → Shazam")
        self.root.geometry("900x700")
        self.root.minsize(740, 610)
        self.root.configure(bg="#131923")
        self.message_queue = queue.Queue()
        self.running = False
        self.cancel = threading.Event()
        self.library = tk.StringVar(value=self.cfg["library"])
        self.mix = tk.StringVar(value="")
        self.shazam = tk.BooleanVar(value=bool(self.cfg["shazam"]))
        self.pitch = tk.BooleanVar(value=bool(self.cfg["tempo_pitch"]))
        self.max_shazam = tk.StringVar(value=str(self.cfg["max_shazam"]))
        self.make_ui()
        self.root.after(100, self.drain_messages)
        ff = locate_ffmpeg(self.cfg)
        if ff:
            self.cfg["ffmpeg_dir"] = ff
            self.log(f"FFmpeg gefunden: {ff}")
        else:
            self.log("ACHTUNG: FFmpeg nicht gefunden – bitte ffmpeg.exe auswählen.")
        if DB.is_file():
            self.log(f"Offline-Datenbank vorhanden: {DB.name}")
        else:
            self.log("Erster Start: Bitte Musikdatenbank aufbauen (einmalig).")

    def make_ui(self):
        style = ttk.Style(self.root)
        if "clam" in style.theme_names(): style.theme_use("clam")
        style.configure("TButton", font=("Segoe UI", 10), padding=7)
        style.configure("TCheckbutton", font=("Segoe UI", 10), background="#131923", foreground="#e6edf5")
        main = tk.Frame(self.root, bg="#131923", padx=18, pady=18)
        main.pack(fill="both", expand=True)
        tk.Label(main, text="SET SCANNER", bg="#131923", fg="#f2f6ff", font=("Segoe UI", 23, "bold")).pack(anchor="w")
        tk.Label(main, text="1. Eigene Musik offline erkennen    2. Unbekannte Stellen optional mit Shazam prüfen    3. TXT speichern",
                 bg="#131923", fg="#a7b4c9", font=("Segoe UI", 10)).pack(anchor="w", pady=(0, 16))
        def chooser_row(title, var, callback):
            tk.Label(main, text=title, bg="#131923", fg="#d6e0ef", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(7, 3))
            row = tk.Frame(main, bg="#131923")
            row.pack(fill="x")
            tk.Entry(row, textvariable=var, font=("Segoe UI", 10), bg="#222b39", fg="#f4f7fb",
                     insertbackground="white", relief="flat").pack(side="left", fill="x", expand=True, ipady=7)
            ttk.Button(row, text="Durchsuchen", command=callback).pack(side="left", padx=(8,0))
        chooser_row("Musikordner (wird nur beim erstmaligen Indexieren eingelesen)", self.library, self.pick_library)
        chooser_row("DJ-Set (MP3/WAV/FLAC/AIFF)", self.mix, self.pick_mix)
        options = tk.Frame(main, bg="#131923")
        options.pack(fill="x", pady=(12, 4))
        ttk.Checkbutton(options, text="Shazam für unbekannte Stellen (Internet, ohne API-Key)", variable=self.shazam).pack(anchor="w")
        ttk.Checkbutton(options, text="Auch DJ-Speed ohne Key-Lock testen (langsamer, gründlicher)", variable=self.pitch).pack(anchor="w", pady=4)
        tk.Label(options, text="Max. Shazam-Abfragen:", bg="#131923", fg="#a7b4c9").pack(side="left", pady=(3,0))
        tk.Spinbox(options, from_=0, to=250, width=6, textvariable=self.max_shazam,
                   bg="#222b39", fg="#ffffff", insertbackground="white").pack(side="left", padx=8, pady=(3,0))
        buttonrow = tk.Frame(main, bg="#131923")
        buttonrow.pack(fill="x", pady=(15, 12))
        self.index_btn = ttk.Button(buttonrow, text="1  MUSIKDATENBANK AUFBAUEN / ERNEUERN", command=self.do_index)
        self.index_btn.pack(side="left", padx=(0,10))
        self.scan_btn = ttk.Button(buttonrow, text="2  SET SCANNEN", command=self.do_scan)
        self.scan_btn.pack(side="left", padx=(0,10))
        self.cancel_btn = ttk.Button(buttonrow, text="Abbrechen", command=self.cancel_scan, state="disabled")
        self.cancel_btn.pack(side="left")
        tk.Label(main, text="Ablauf / Protokoll", bg="#131923", fg="#d6e0ef", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.logbox = scrolledtext.ScrolledText(main, height=15, font=("Consolas", 9),
                                                bg="#0b1019", fg="#d6e0ef", insertbackground="white", relief="flat", wrap="word")
        self.logbox.pack(fill="both", expand=True, pady=(6,0))
        self.logbox.configure(state="disabled")
        toolrow = tk.Frame(main, bg="#131923")
        toolrow.pack(fill="x", pady=(8, 0))
        ttk.Button(toolrow, text="Ergebnisordner öffnen", command=lambda: self.open_folder(OUTPUT)).pack(side="left")
        ttk.Button(toolrow, text="FFmpeg.exe auswählen", command=self.pick_ffmpeg).pack(side="left", padx=8)
        ttk.Button(toolrow, text="audfprint-Ordner auswählen", command=self.pick_audfprint).pack(side="left")
        tk.Label(main, text="Prototyp: Falscherkennungen sind möglich. Große Bibliotheken brauchen viel RAM und Laufzeit.",
                 bg="#131923", fg="#a7b4c9", font=("Segoe UI", 9)).pack(anchor="w", pady=(8,0))

    def log(self, msg):
        self.message_queue.put(("log", f"[{stamp()}] {msg}"))

    def drain_messages(self):
        try:
            while True:
                kind, obj = self.message_queue.get_nowait()
                if kind == "log":
                    self.logbox.configure(state="normal")
                    self.logbox.insert("end", str(obj)+"\n")
                    self.logbox.see("end")
                    self.logbox.configure(state="disabled")
                elif kind == "done":
                    self.set_running(False)
                    messagebox.showinfo("SET SCANNER", obj)
                elif kind == "error":
                    self.set_running(False)
                    messagebox.showerror("SET SCANNER", obj)
        except queue.Empty:
            pass
        self.root.after(100, self.drain_messages)

    def pick_library(self):
        selected = filedialog.askdirectory(title="Ordner mit deiner Musik", initialdir=self.library.get() if Path(self.library.get()).is_dir() else str(Path.home()))
        if selected: self.library.set(selected)

    def pick_mix(self):
        selected = filedialog.askopenfilename(title="Fertiges DJ-Set auswählen", initialdir=str(DEFAULT_AUDIO),
                                              filetypes=[("Audio", AUDIOFILETYPES), ("Alle Dateien", "*.*")])
        if selected: self.mix.set(selected)

    def pick_ffmpeg(self):
        selected = filedialog.askopenfilename(title="ffmpeg.exe auswählen", filetypes=[("ffmpeg.exe", "ffmpeg.exe"), ("Programme", "*.exe")])
        if selected:
            self.cfg["ffmpeg_dir"] = str(Path(selected).parent)
            save_config(self.cfg)
            self.log(f"FFmpeg-Ordner gespeichert: {self.cfg['ffmpeg_dir']}")

    def pick_audfprint(self):
        selected = filedialog.askdirectory(title="Ordner mit audfprint.py auswählen")
        if selected:
            self.cfg["audfprint_source"] = selected
            save_config(self.cfg)
            self.log(f"audfprint-Quelle: {selected}")

    def open_folder(self, path: Path):
        if os.name == "nt": os.startfile(str(path))
        else: messagebox.showinfo("SET SCANNER", f"Ordner: {path}")

    def update_cfg(self):
        try:
            limit = int(self.max_shazam.get())
        except ValueError:
            raise RuntimeError("Maximale Shazam-Anfragen müssen eine Zahl sein.")
        self.cfg.update({"library": self.library.get().strip(), "shazam": bool(self.shazam.get()),
                         "tempo_pitch": bool(self.pitch.get()), "max_shazam": min(max(0,limit),250)})
        ff = locate_ffmpeg(self.cfg)
        if not ff:
            raise RuntimeError("FFmpeg nicht gefunden. Bitte ffmpeg.exe auswählen.")
        self.cfg["ffmpeg_dir"] = ff
        save_config(self.cfg)

    def set_running(self, state):
        self.running = state
        self.index_btn.configure(state="disabled" if state else "normal")
        self.scan_btn.configure(state="disabled" if state else "normal")
        self.cancel_btn.configure(state="normal" if state else "disabled")

    def start(self, fn):
        if self.running: return
        try:
            self.update_cfg()
        except Exception as exc:
            messagebox.showerror("SET SCANNER", str(exc))
            return
        self.cancel.clear()
        self.set_running(True)
        def job():
            try:
                msg = fn()
                self.message_queue.put(("done", msg))
            except Exception as exc:
                trace = traceback.format_exc()
                (LOGS/"letzter_fehler.txt").write_text(trace, encoding="utf-8")
                self.log(f"FEHLER: {exc}")
                self.message_queue.put(("error", f"{exc}\n\nDetails: {LOGS/'letzter_fehler.txt'}"))
        threading.Thread(target=job, daemon=True).start()

    def cancel_scan(self):
        self.cancel.set()
        self.log("Abbruch angefordert – laufender Schritt wird beendet.")

    def do_index(self):
        if DB.is_file() and not messagebox.askyesno("Datenbank erneuern", "Die vorhandene Musikdatenbank wirklich neu erstellen? Das kann dauern."):
            return
        self.start(lambda: self._index())

    def _index(self):
        build_database(self.cfg, self.log, self.cancel)
        return f"Musikdatenbank erstellt:\n{DB}\n\nJetzt ein DJ-Set auswählen und 'SET SCANNEN' klicken."

    def do_scan(self):
        mix = Path(self.mix.get().strip())
        if not mix.is_file():
            self.pick_mix()
            mix = Path(self.mix.get().strip())
        if not mix.is_file():
            return
        if not DB.is_file():
            messagebox.showwarning("Datenbank fehlt", "Bitte zuerst die Musikdatenbank aufbauen.")
            return
        self.start(lambda: self._scan(mix))

    def _scan(self, mix: Path):
        cfg = dict(self.cfg)
        env = env_with_ffmpeg(cfg["ffmpeg_dir"])
        duration = get_duration(mix, env)
        self.log(f"Set: {mix.name} | {hhmmss(duration)}")
        self.log("Starte lokale Tempoanalyse. Die Geschwindigkeit wird automatisch ausprobiert.")
        off, weak, errors = scan_offline(mix, cfg, duration, self.log, self.cancel)
        sha = []
        if cfg["shazam"] and cfg["max_shazam"]:
            times = unknown_probe_times(duration, off, cfg["max_shazam"])
            self.log(f"Shazam-Fallback für {len(times)} unbekannte Zeitpositionen (online, ohne API-Key)")
            found, errs = asyncio.run(shazam_probes(mix, times, cfg, self.log, self.cancel))
            sha.extend(found)
            errors.extend(errs)
        else:
            self.log("Shazam-Fallback deaktiviert.")
        report = final_report(mix, duration, off, weak, sha, errors, cfg)
        self.log(f"FERTIG. TXT gespeichert: {report}")
        return f"Scan abgeschlossen!\n\nOffline bestätigt: {len(off)}\nShazam-Beobachtungen: {len(sha)}\n\nTXT: {report}"

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    GUI().run()
