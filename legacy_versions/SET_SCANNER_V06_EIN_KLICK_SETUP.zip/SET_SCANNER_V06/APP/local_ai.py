# -*- coding: utf-8 -*-
"""Optional local LLM report review. Does not identify audio or invent tracks.

LM Studio: http://127.0.0.1:1234/v1/chat/completions
Ollama:   http://127.0.0.1:11434/api/chat
"""
from __future__ import annotations
import json
import urllib.request
import urllib.error
from pathlib import Path


def request_json(url, payload=None, timeout=4):
    headers={'Content-Type':'application/json'}
    body=json.dumps(payload).encode('utf-8') if payload is not None else None
    req=urllib.request.Request(url,data=body,headers=headers,method='POST' if body else 'GET')
    with urllib.request.urlopen(req,timeout=timeout) as r:
        return json.loads(r.read().decode('utf-8'))


def detect():
    """Return (provider, model, info), or (None,None,diagnostic).

    Both endpoints always use loopback addresses. Nothing is sent externally.
    """
    diagnostics=[]
    try:
        data=request_json('http://127.0.0.1:1234/v1/models', timeout=1.5)
        models=[x.get('id','') for x in data.get('data',[]) if x.get('id')]
        if models:return ('LM Studio',models[0],f'LM Studio bereit: {models[0]}')
        diagnostics.append('LM Studio läuft, aber kein Modell geladen')
    except (OSError,ValueError,KeyError) as e:
        diagnostics.append('LM Studio nicht erreichbar')
    try:
        data=request_json('http://127.0.0.1:11434/api/tags', timeout=1.5)
        models=[x.get('name','') for x in data.get('models',[]) if x.get('name')]
        if models:return ('Ollama',models[0],f'Ollama bereit: {models[0]}')
        diagnostics.append('Ollama läuft, aber kein Modell installiert')
    except (OSError,ValueError,KeyError):
        diagnostics.append('Ollama nicht erreichbar')
    return (None,None,' / '.join(diagnostics))


SYSTEM = """Du bist eine Prüf- und Formatierungshilfe für DJ-Set-Tracklists.
Nur Belege aus dem gelieferten Scannerbericht dürfen verwendet werden.
ERFINDE NIEMALS Songtitel, Zeitstempel oder Erkennungsquellen.
Wenn es Widersprüche oder zweifelhafte Matches gibt, markiere sie als unsicher.
Korrigiere keine Namen nach Weltwissen; gib lediglich mögliche Dubletten und auffällige Widersprüche an.
Ausgabe in DEUTSCH mit Rubriken: Bestätigte Befunde, Mögliche Dubletten, Unsichere Treffer, Hinweise zur manuellen Prüfung.
Schreibe keine erfundenen Matches und keine geschätzten Zeiten."""


def review_report(report_path: Path, max_chars=36000):
    """Write a separate *_KI_PRUEFUNG.txt; NEVER overwrite the scan's evidence."""
    report_path=Path(report_path)
    provider,model,info=detect()
    if not provider:
        raise RuntimeError('Keine lokale KI bereit: '+info)
    full=report_path.read_text(encoding='utf-8-sig',errors='replace')
    if not full.strip():
        raise RuntimeError('Ergebnisdatei enthält keinen Text.')
    # Restrict to model's context; disclose truncation instead of fabricating coverage.
    excerpt=full[:max_chars]
    clipped=len(full)>len(excerpt)
    prompt='Prüfe ausschliesslich diesen Scannerbericht. Keine neuen Tracks erzeugen.\n\n'+excerpt
    messages=[{'role':'system','content':SYSTEM},{'role':'user','content':prompt}]
    if provider=='LM Studio':
        data=request_json('http://127.0.0.1:1234/v1/chat/completions',
                {'model':model,'messages':messages,'temperature':0,'max_tokens':1400},timeout=180)
        result=data['choices'][0]['message']['content']
    else:
        data=request_json('http://127.0.0.1:11434/api/chat',
                {'model':model,'messages':messages,'stream':False,'options':{'temperature':0,'num_predict':1400}},timeout=180)
        result=data['message']['content']
    if not isinstance(result,str) or not result.strip():
        raise RuntimeError('Die lokale KI hat keinen auswertbaren Text zurückgegeben.')
    out=report_path.with_name(report_path.stem+'_KI_PRUEFUNG.txt')
    out.write_text('SET SCANNER · OPTIONALE LOKALE KI-PRÜFUNG\n'
                   f'Backend: {provider} / {model}\n'
                   'KEINE AUDIO-ERKENNUNG. Nur Hinweise zu vorhandenen Scanner-Treffern.\n'
                   + ('ACHTUNG: Bericht wegen Kontextlänge nur teilweise geprüft.\n' if clipped else '')
                   + '\n'+result.strip()+'\n',encoding='utf-8-sig')
    return out
