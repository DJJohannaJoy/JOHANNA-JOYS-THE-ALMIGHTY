# -*- coding: utf-8 -*-
"""FIRST SPARK · genuine Tkinter controls with custom crimson skin.

No pre-rendered fake screenshot is used as an interface: every button, status,
progress widget, file input and results table below is interactive.
"""
from __future__ import annotations
import tkinter as tk
from tkinter import ttk, scrolledtext
from pathlib import Path
from PIL import Image, ImageTk, ImageDraw, ImageFilter
import random

BASE = '#101114'
PANEL = '#191A1E'
PANEL2 = '#202127'
FIELD = '#141518'
LINE = '#33343B'
RED = '#A20C23'
HOT = '#EF163E'
RED_DARK = '#680716'
TEXT = '#F5F2F3'
MUTE = '#AEB0B7'
GOOD = '#39DC8F'
BAD = '#FE4E62'
CAUTION = '#E8B66A'


def _raster_panel(width, height, fill='#191A1E', edge='#444148', radius=16):
    """Rounded layered, shaded panel. All its contents are real Tk widgets."""
    scale=2
    W=max(8,int(width))*scale; H=max(8,int(height))*scale
    im=Image.new('RGBA',(W,H),(0,0,0,0))
    mask=Image.new('L',(W,H),0)
    md=ImageDraw.Draw(mask)
    md.rounded_rectangle((2*scale,2*scale,W-2*scale,H-2*scale),radius=radius*scale,fill=255)
    px=im.load()
    for y in range(H):
        t=y/max(1,H-1)
        for x in range(W):
            # Subtle gradients make the panels much closer to the reference.
            lateral=1.5 * abs(x/W-.5)
            v=int(23 + 3*(1-t) + lateral)
            px[x,y]=(v,v+1,v+4,255)
    im.putalpha(mask)
    d=ImageDraw.Draw(im)
    d.rounded_rectangle((2*scale,2*scale,W-2*scale,H-2*scale),radius=radius*scale,
                        outline='#49434C',width=2*scale)
    d.arc((4*scale,4*scale,W-4*scale,H-4*scale),190,340,fill='#4B2732',width=scale)
    return ImageTk.PhotoImage(im.resize((W//scale,H//scale),Image.Resampling.LANCZOS))


class RoundedCard(tk.Canvas):
    """Round panel perimeter, with a genuine Tk frame for input widgets."""
    def __init__(self,parent,padx,pady,desired_height=170):
        super().__init__(parent,bg=BASE,highlightthickness=0,bd=0,relief='flat',height=desired_height)
        self.inner=tk.Frame(self,bg=PANEL,padx=padx,pady=pady)
        self._win=self.create_window(8,8,window=self.inner,anchor='nw')
        self._bmp=None
        self._last=(0,0)
        self.bind('<Configure>',self._resize)
    def _resize(self,event):
        w,h=event.width,event.height
        self.itemconfigure(self._win,width=max(1,w-16),height=max(1,h-16))
        if (w,h)!=self._last and w>=30 and h>=25:
            self._bmp=_raster_panel(w,h)
            self.delete('panel_background')
            self.create_image(0,0,image=self._bmp,anchor='nw',tags='panel_background')
            self.tag_lower('panel_background')
            self._last=(w,h)


def _button_image(w,h,outline,hover,disabled):
    k=2;W=w*k;H=h*k
    im=Image.new('RGBA',(W,H),(0,0,0,0))
    pix=im.load()
    for y in range(H):
        t=y/max(1,H-1)
        if disabled: col=(54,45,49)
        elif outline: col=(37,24,29) if hover else (27,24,29)
        elif hover: col=(max(83,int(237-110*t)),max(4,int(17-13*t)),max(25,int(50-23*t)))
        else: col=(max(65,int(215-120*t)),max(1,int(12-8*t)),max(17,int(39-20*t)))
        for x in range(W):pix[x,y]=(*col,255)
    # Mask the entire fill to rounded corners, including antialiased edges.
    mask=Image.new('L',(W,H),0)
    md=ImageDraw.Draw(mask);md.rounded_rectangle((3,3,W-4,H-4),radius=10*k,fill=255)
    im.putalpha(mask)
    d=ImageDraw.Draw(im)
    d.rounded_rectangle((3,3,W-4,H-4),radius=10*k,outline=('#FF344E' if hover else '#C82B42') if not disabled else '#51414A',width=2*k)
    if not outline and not disabled:d.line((25,7,W-25,7),fill='#EF5163',width=2)
    return ImageTk.PhotoImage(im.resize((w,h),Image.Resampling.LANCZOS))


class BloodButton(tk.Canvas):
    """Real clickable red button with antialiased rounded rectangle and hover state."""
    def __init__(self,parent,title,command,width=175,height=43,outline_only=False,
                 font_size=11,fg=TEXT,**kw):
        super().__init__(parent,width=width,height=height,bg=parent.cget('bg'),
                         highlightthickness=0,bd=0,relief='flat',cursor='hand2',**kw)
        self.caption=title;self.action=command;self.outline_only=outline_only
        self.font_size=font_size;self.fgcolor=fg
        self.disabled=False;self.over=False;self._bmp=None;self._last=None
        self.bind('<Configure>',lambda e:self._paint())
        self.bind('<Enter>',lambda e:self._hover(True))
        self.bind('<Leave>',lambda e:self._hover(False))
        self.bind('<ButtonRelease-1>',self._clicked)
        self._paint()
    def configure(self,cnf=None,**kw):
        if cnf and isinstance(cnf,dict):kw.update(cnf)
        if 'state' in kw:
            self.disabled=str(kw.pop('state'))=='disabled'
            self['cursor']='arrow' if self.disabled else 'hand2'
        if 'text' in kw:self.caption=kw.pop('text')
        if kw:super().configure(**kw)
        self._paint()
    config=configure
    def _hover(self,on):
        if not self.disabled:self.over=on;self._paint()
    def _clicked(self,e):
        if not self.disabled and self.action:self.action()
    def _paint(self):
        w=max(int(self.winfo_width()),int(self.cget('width')))
        h=max(int(self.winfo_height()),int(self.cget('height')))
        if w<10 or h<10:return
        image_key=(w,h,self.outline_only,self.over,self.disabled)
        if image_key!=self._last:
            self._bmp=_button_image(w,h,self.outline_only,self.over,self.disabled)
            self._last=image_key
        self.delete('all')
        self.create_image(0,0,image=self._bmp,anchor='nw')
        self.create_text(w/2,h/2,text=self.caption,fill='#A19AA0' if self.disabled else self.fgcolor,
                         font=('Segoe UI',self.font_size,'bold'))


class Header(tk.Canvas):
    """Approved brand artwork only. Settings gear is a genuine click target."""
    def __init__(self,parent,app,source:Path):
        super().__init__(parent,bg='#110A0E',height=118,highlightthickness=0,bd=0)
        self.app=app;self._source=Image.open(source).convert('RGB')
        self._img=None;self._last_width=0;self._hovered=False
        self.bind('<Configure>',self.redraw)
        self.bind('<ButtonRelease-1>',self.click)
        self.bind('<Motion>',self.move)
        self.bind('<Leave>',lambda event:self.configure(cursor='arrow'))
    def in_gear(self,event):
        return event.x>=self.winfo_width()-126 and 12 <= event.y <= 112
    def click(self,event):
        if self.in_gear(event): self.app.toggle_settings()
    def move(self,event):
        self.configure(cursor='hand2' if self.in_gear(event) else 'arrow')
    def redraw(self,event=None):
        w=self.winfo_width()
        if w<10 or self._last_width==w:return
        self._last_width=w
        self.delete('all')
        # The approved mockup's artistic brand strip is embedded as a decorative
        # asset. All operational status, controls and text BELOW it are live.
        im=self._source.resize((w,118),Image.Resampling.LANCZOS)
        self._img=ImageTk.PhotoImage(im)
        self.create_image(0,0,anchor='nw',image=self._img)


class GlowProgress(tk.Canvas):
    """Animated indeterminate progress showing actual busy/idle state."""
    def __init__(self,parent,**kw):
        super().__init__(parent,bg=parent.cget('bg'),highlightthickness=0,
                         height=17,bd=0,**kw)
        self.busy=False;self.phase=0;self.job=None
        self.bind('<Configure>',lambda e:self.draw())
    def start(self,interval=30):
        if self.busy:return
        self.busy=True
        self._tick()
    def stop(self):
        self.busy=False
        if self.job:
            try:self.after_cancel(self.job)
            except tk.TclError:pass
            self.job=None
        self.draw()
    def _tick(self):
        if not self.busy:return
        self.phase=(self.phase+0.012)%1
        self.draw()
        self.job=self.after(35,self._tick)
    def draw(self):
        w=max(20,self.winfo_width());h=max(10,self.winfo_height())
        self.delete('all')
        self.create_rectangle(1,2,w-2,h-3,fill='#2A2D34',outline='#4D4752',width=1)
        if self.busy:
            length=max(70,int(w*.25))
            x=int((w+length)*self.phase)-length
            self.create_rectangle(max(3,x),4,min(w-4,x+length),h-5,
                                  fill='#C60B32',outline='')
            self.create_line(max(3,x),4,min(w-4,x+length),4,
                             fill='#FF3D56',width=2)


class StageProxy:
    """Tiny adapter for the existing scan-event API."""
    def __init__(self,strip,key,role):
        self.strip=strip
        self.key=key
        self.role=role
    def configure(self,**kw):
        if self.role=='dot':
            self.strip.states[self.key]=(kw.get('text','○'),kw.get('fg',MUTE))
        else:
            self.strip.caption_colors[self.key]=kw.get('fg',MUTE)
        self.strip.redraw()


class StageStrip(tk.Canvas):
    """Real stepper: connector line, state-driven glowing nodes and stable text."""
    def __init__(self,parent,spec):
        super().__init__(parent,bg=PANEL,highlightthickness=0,bd=0,height=70)
        self.spec=spec
        self.states={key:('◉',HOT) if i==0 else ('○',MUTE)
                     for i,(key,_) in enumerate(spec)}
        self.caption_colors={key:TEXT if i==0 else MUTE for i,(key,_) in enumerate(spec)}
        self.bind('<Configure>',lambda e:self.redraw())
    def redraw(self):
        w=max(self.winfo_width(),300)
        self.delete('all')
        count=len(self.spec)
        xs=[110+i*(w-155)/(count-1) for i in range(count)]
        y=16
        self.create_line(xs[0],y,xs[-1],y,fill='#68676C',width=2)
        for ix,(key,title) in enumerate(self.spec):
            x=xs[ix]
            sym,color=self.states[key]
            if sym=='✓': fill=GOOD
            elif sym=='◉': fill=HOT
            elif sym=='✕': fill=BAD
            elif sym=='–': fill=CAUTION
            else: fill=PANEL
            self.create_oval(x-11,y-11,x+11,y+11,outline=color,width=2,fill=fill)
            if sym=='✓':
                self.create_text(x,y,text='✓',font=('Segoe UI',11,'bold'),fill=BASE)
            elif sym=='✕':
                self.create_text(x,y,text='×',font=('Segoe UI',14,'bold'),fill=BASE)
            elif sym=='◉':
                self.create_oval(x-5,y-5,x+5,y+5,fill='#FFD0D7',outline='')
            self.create_text(x,35,text=title,anchor='n',justify='center',width=(w-40)/count,
                             font=('Segoe UI',9,'bold'),fill=self.caption_colors[key])


def label(parent,text,size=11,weight='normal',color=TEXT,bg=None,anchor='w'):
    return tk.Label(parent,text=text,bg=bg or parent.cget('bg'),fg=color,
                    font=('Segoe UI',size,weight),anchor=anchor)


def placeholder(entry,var,message):
    """View-only prompt that disappears immediately on typing."""
    hint=tk.Label(entry.master,text=message,bg=FIELD,fg='#77737E',
                  font=('Segoe UI',10),anchor='w',cursor='xterm')
    def show(*_):
        if var.get() or entry.focus_get()==entry:hint.place_forget()
        else:hint.place(x=42,y=3,relheight=.78)
    hint.bind('<Button-1>',lambda e:(hint.place_forget(),entry.focus_set()))
    entry.bind('<FocusIn>',lambda e:hint.place_forget(),add='+')
    entry.bind('<FocusOut>',show,add='+')
    var.trace_add('write',show)
    entry.after_idle(show)



def card(parent,padx=14,pady=10,desired_height=170):
    holder=RoundedCard(parent,padx,pady,desired_height)
    return holder,holder.inner


def build_ui(a):
    """Construct the approved three-column/header + full-width scanner UI."""
    root=a.root
    root.configure(bg=BASE)
    root.title("Johanna Joy's THE ALMIGHTY")
    root.geometry('1610x900')
    root.minsize(1250,790)
    root.columnconfigure(0,weight=1)
    root.rowconfigure(2,weight=1)

    header=Header(root,a,a.C_APP/'assets'/'approved_banner.png')
    header.grid(row=0,column=0,sticky='ew')

    strip=tk.Frame(root,bg=PANEL2,height=45,highlightthickness=1,highlightbackground='#97172D')
    strip.grid(row=1,column=0,sticky='ew')
    strip.grid_propagate(False)
    label(strip,'OFFLINE    •    MIX-ID    •    SHAZAM',11,'bold',TEXT).pack(side='right',padx=31)

    body=tk.Frame(root,bg=BASE,padx=18,pady=12)
    body.grid(row=2,column=0,sticky='nsew')
    body.columnconfigure(0,weight=1)
    body.rowconfigure(2,weight=1,minsize=155)
    body.rowconfigure(0,minsize=259)

    top=tk.Frame(body,bg=BASE)
    top.grid(row=0,column=0,sticky='nsew',pady=(0,10))
    top.columnconfigure(0,weight=52,uniform='toparea')
    top.columnconfigure(1,weight=25,uniform='toparea')
    top.columnconfigure(2,weight=23,uniform='toparea')
    top.rowconfigure(0,weight=1)

    upload_wrap,upload=card(top,12,11,desired_height=259)
    upload_wrap.grid(row=0,column=0,sticky='nsew',padx=(0,10))
    upload.columnconfigure(0,weight=1)
    upload.rowconfigure(0,weight=1)

    # The drop zone is a functional, animated-focus Canvas, not a static picture.
    drop=tk.Canvas(upload,height=106,bg='#1C151A',highlightthickness=0,bd=0,cursor='hand2')
    drop.grid(row=0,column=0,sticky='nsew',pady=(0,5))
    def paint_drop(event=None):
        w,h=max(drop.winfo_width(),20),max(drop.winfo_height(),20)
        drop.delete('all')
        # Red texture is generated locally; the drop zone is NOT a pasted UI
        # screenshot and remains an actual drag target.
        texture=Image.new('RGB',(w,h),'#19171C')
        pixels=texture.load()
        for yy in range(h):
            for xx in range(w):
                edge=min(xx,w-xx)
                scatter=(xx*17+yy*31)%83
                bleed=max(0,1-edge/160)
                fleck=8 if scatter<3 else (4 if scatter<13 else 0)
                pixels[xx,yy]=(int(24+bleed*24+fleck),int(17+fleck*.22),int(22+bleed*3))
        # dashed rounded perimeter, hand-textured glow, text remains editable
        pen=ImageDraw.Draw(texture)
        import math
        r=12
        pts=[]
        for px in range(r,w-r):pts.append((px,4))
        for t in range(91,181,3):pts.append((w-r+r*math.cos(math.radians(t)),r-r*math.sin(math.radians(t))))
        # Simpler dash segments on horizontal and vertical spans.
        for xx in range(9,w-12,14):pen.line((xx,4,min(w-10,xx+8),4),fill='#E71D42',width=2)
        for xx in range(10,w-12,14):pen.line((xx,h-5,min(w-10,xx+8),h-5),fill='#E71D42',width=2)
        for yy in range(12,h-15,14):
            pen.line((5,yy,5,min(h-12,yy+8)),fill='#E71D42',width=2)
            pen.line((w-6,yy,w-6,min(h-12,yy+8)),fill='#E71D42',width=2)
        pen.arc((4,4,26,26),180,270,fill='#E71D42',width=2)
        pen.arc((w-27,4,w-5,26),270,360,fill='#E71D42',width=2)
        pen.arc((4,h-27,26,h-5),90,180,fill='#E71D42',width=2)
        pen.arc((w-27,h-27,w-5,h-5),0,90,fill='#E71D42',width=2)
        drop._art=ImageTk.PhotoImage(texture)
        drop.create_image(0,0,image=drop._art,anchor='nw')
        drop.create_text(w/2,h/2-12,text='HIER REINZIEHEN',fill=TEXT,
                         font=('Segoe UI',22,'bold'))
        drop.create_text(w/2,h/2+22,text='MP3   •   WAV   •   FLAC   •   AIFF   •   VIDEO',
                         fill=MUTE,font=('Segoe UI',10))
    drop.bind('<Configure>',paint_drop)
    drop.bind('<ButtonRelease-1>',lambda e:a.pick_set())
    if a.DND_OK:
        drop.drop_target_register(a.DND_FILES)
        drop.dnd_bind('<<Drop>>',a._dropped)

    form=tk.Frame(upload,bg=PANEL)
    form.grid(row=1,column=0,sticky='ew',pady=(0,6))
    form.grid_columnconfigure(0,weight=1)
    filebox=tk.Frame(form,bg=FIELD,highlightthickness=1,highlightbackground='#51505A')
    filebox.grid(row=0,column=0,sticky='nsew')
    label(filebox,'▱',15,'bold',MUTE,bg=FIELD).pack(side='left',padx=(12,7))
    fentry=a._entry(filebox,a.set_path)
    fentry.configure(font=('Segoe UI',11),bg=FIELD,highlightthickness=0)
    fentry.pack(side='left',fill='both',expand=True,ipady=8)
    placeholder(fentry,a.set_path,'Noch kein Set ausgewählt')
    browse=BloodButton(form,'DURCHSUCHEN',a.pick_set,width=198,height=41,font_size=11)
    browse.grid(row=0,column=1,sticky='nsew',padx=(13,0))

    linkhead=tk.Frame(upload,bg=PANEL)
    linkhead.grid(row=2,column=0,sticky='ew',pady=(0,3))
    label(linkhead,'◈',17,'bold',HOT).pack(side='left',padx=(0,8))
    label(linkhead,'YOUTUBE / SOUNDCLOUD / MIXCLOUD',11,'bold').pack(side='left')
    links=tk.Frame(upload,bg=PANEL)
    links.grid(row=3,column=0,sticky='ew')
    links.grid_columnconfigure(0,weight=1)
    linkbox=tk.Frame(links,bg=FIELD,highlightthickness=1,highlightbackground='#51505A')
    linkbox.grid(row=0,column=0,sticky='nsew')
    label(linkbox,'◈',13,'bold',MUTE,bg=FIELD).pack(side='left',padx=(12,9))
    lentry=a._entry(linkbox,a.media_url)
    lentry.configure(font=('Segoe UI',11),bg=FIELD,highlightthickness=0)
    lentry.pack(side='left',fill='both',expand=True,ipady=8)
    placeholder(lentry,a.media_url,'Link hier einfügen')
    load=BloodButton(links,'LINK LADEN',a.start_download,width=198,height=41,font_size=11)
    load.grid(row=0,column=1,sticky='nsew',padx=(13,0))
    a.file_button=browse
    a.link_button=load

    right_wrap,right=card(top,13,12,desired_height=259)
    right_wrap.grid(row=0,column=1,sticky='nsew',padx=(0,10))
    label(right,'☷   VORAUSSETZUNGEN',16,'bold').pack(anchor='w',pady=(0,10))
    a.statuses={}
    a.status_actions={}
    captions=[('ffmpeg','FFmpeg','EINRICHTEN'),('db','Musikdatenbank','ANLEGEN'),
              ('offline','Offline-Engine','EINRICHTEN'),('mixid','mix-id','EINRICHTEN'),
              ('shazam','ShazamIO','EINRICHTEN')]
    for key,desc,fixcaption in captions:
        row=tk.Frame(right,bg=PANEL,height=34)
        row.pack(fill='x',pady=1)
        row.pack_propagate(False)
        row.grid_columnconfigure(1,weight=1)
        sym=label(row,'○',16,'bold',MUTE)
        sym.grid(row=0,column=0,sticky='w',padx=(3,9))
        label(row,desc,12,'normal').grid(row=0,column=1,sticky='w')
        stat=label(row,'Prüfe …',10,'bold',MUTE)
        stat.grid(row=0,column=2,sticky='e',padx=(5,0))
        fix=BloodButton(row,fixcaption,lambda k=key:a.fix_prerequisite(k),
                        width=115,height=27,outline_only=True,font_size=9)
        fix.grid(row=0,column=3,padx=(7,0))
        fix.grid_remove()
        a.statuses[key]=(sym,stat)
        a.status_actions[key]=fix

    ai_wrap,ai=card(top,12,12,desired_height=259)
    ai_wrap.grid(row=0,column=2,sticky='nsew')
    label(ai,'▤   LOKALE KI  ·  OPTIONAL',15,'bold').pack(anchor='w',pady=(0,11))
    BloodButton(ai,'LM STUDIO INSTALLIEREN',a.install_local_ai,height=39,
                outline_only=True,font_size=11).pack(fill='x',pady=(0,8))
    BloodButton(ai,'OLLAMA',a.install_ollama,height=39,
                outline_only=True,font_size=11).pack(fill='x',pady=(0,8))
    BloodButton(ai,'VERBINDUNG TESTEN',a.check_local_ai,height=39,
                outline_only=True,font_size=11).pack(fill='x',pady=(0,7))
    a.ai_status_text=tk.StringVar(value='Optional · keine KI-Verbindung geprüft')
    tk.Label(ai,textvariable=a.ai_status_text,bg=PANEL,fg=MUTE,
             font=('Segoe UI',9),wraplength=290,anchor='w',justify='left').pack(fill='x')

    # A row spanning all columns makes scanning a single, easy-to-follow path.
    flow_wrap,flow=card(body,18,12,desired_height=144)
    flow_wrap.grid(row=1,column=0,sticky='nsew',pady=(0,10))
    label(flow,'SCAN-ABLAUF',14,'bold').pack(anchor='w',pady=(0,7))
    flowrow=tk.Frame(flow,bg=PANEL)
    flowrow.pack(fill='x',expand=False)
    nodes=tk.Frame(flowrow,bg=PANEL)
    nodes.pack(side='left',fill='x',expand=True,padx=(0,16))
    stagespec=[('setup','DATEIEN\nVORBEREITEN'),('A','SCHNELLSCAN\nOFFLINE'),
               ('B','TIEFENSCAN\nOFFLINE – TEMPO'),('M','MIX-ID\n(ORIGINAL)'),
               ('S','SHAZAM\nFÜR LÜCKEN'),('E','TXT ERGEBNIS\nSPEICHERN')]
    stagebar=StageStrip(nodes,stagespec)
    stagebar.pack(fill='x')
    a.stages={key:(StageProxy(stagebar,key,'dot'),StageProxy(stagebar,key,'caption'))
              for key,_ in stagespec}
    a.start_button=BloodButton(flowrow,'SET SCANNEN',a.start_scan,
                               width=470,height=70,font_size=24)
    a.start_button.pack(side='right',padx=(0,1),pady=(0,0))
    a.timeline_nodes={}

    hits_wrap,hits=card(body,13,10,desired_height=170)
    hits_wrap.grid(row=2,column=0,sticky='nsew',pady=(0,10))
    hithead=tk.Frame(hits,bg=PANEL)
    hithead.pack(fill='x',pady=(0,7))
    label(hithead,'☷   LIVE-TREFFER',14,'bold').pack(side='left')
    label(hithead,'Schätzwerte – bitte nachhören',10,color=MUTE).pack(side='left',padx=(8,0))
    a.stop_button=BloodButton(hithead,'ABBRECHEN',a.stop,width=105,height=31,
                              outline_only=True,font_size=9)
    # Only show cancellation while actually scanning, to match the clean UI.
    a.stop_button.configure(state='disabled')

    style=ttk.Style(root)
    if 'clam' in style.theme_names(): style.theme_use('clam')
    style.configure('Almighty.Treeview',background='#111317',foreground=TEXT,
                    fieldbackground='#111317',borderwidth=0,rowheight=30,
                    font=('Segoe UI',10))
    style.configure('Almighty.Treeview.Heading',background='#25272D',foreground=TEXT,
                    relief='flat',font=('Segoe UI',10,'bold'))
    style.map('Almighty.Treeview',background=[('selected','#812031')],
              foreground=[('selected',TEXT)])
    a.result_table=ttk.Treeview(hits,columns=('time','title','source'),
                                show='headings',style='Almighty.Treeview',height=6)
    for key,name,width,stretch in [('time','ZEIT',160,False),('title','TITEL / ARTIST',700,True),
                                   ('source','QUELLE',160,False)]:
        a.result_table.heading(key,text=name)
        a.result_table.column(key,width=width,stretch=stretch,anchor='w')
    a.result_table.pack(fill='both',expand=True)
    # Empty rows are visual grid guides, never fabricated recognitions;
    # scanner._render_hits clears them before showing actual results.
    a.result_table.tag_configure('empty0',background='#15171A')
    a.result_table.tag_configure('empty1',background='#191B1E')
    for i in range(4):a.result_table.insert('','end',values=('','',''),tags=('empty'+str(i%2),))

    foot_wrap,foot=card(body,12,9,desired_height=93)
    foot_wrap.grid(row=3,column=0,sticky='ew')
    foot_header=label(foot,'▤   FORTSCHRITT / PROTOKOLL',13,'bold')
    foot_header.pack(anchor='w',pady=(0,6))
    row=tk.Frame(foot,bg=PANEL)
    row.pack(fill='x')
    style.configure('Spark.Horizontal.TProgressbar',troughcolor='#383A42',
                    background=HOT,lightcolor=HOT,darkcolor=RED_DARK,
                    thickness=12,borderwidth=0)
    a.progressbar=GlowProgress(row)
    a.progressbar.pack(side='left',fill='x',expand=True,padx=(2,12))
    a.progress=tk.StringVar(value='Bereit für den ersten Scan')
    tk.Label(row,textvariable=a.progress,bg=PANEL,fg=MUTE,
             font=('Segoe UI',9),anchor='e',width=55).pack(side='right')
    a.logbox=scrolledtext.ScrolledText(foot,height=2,wrap='word',bg='#0E1013',fg='#CFCBD0',
                                       insertbackground=TEXT,relief='flat',font=('Consolas',9))
    # Keep the diagnostic log available on click, but avoid a permanent
    # distracting empty textbox not present in the approved design.
    a.logbox.configure(state='disabled')
    def toggle_log(event=None):
        if a.logbox.winfo_manager():a.logbox.pack_forget()
        else:a.logbox.pack(fill='x',pady=(7,0))
    foot_header.configure(cursor='hand2')
    foot_header.bind('<Button-1>',toggle_log)

    a._build_settings()
