#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SET SCANNER 0.7 | Windows | Anthrazit + Karminrot.
Prototype, source included. Never overwrites the user's source audio/library.
"""
from __future__ import annotations
import asyncio
import datetime as dt
import importlib.util
import json
import os
from pathlib import Path
import queue
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import traceback
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
from urllib.parse import urlparse

import scanner_core as C
import engine_external as X
import local_ai as L
import webbrowser

try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
    DND_OK = True
except ImportError:
    TkinterDnD = None
    DND_OK = False

BG = '#1C1F23'
PANEL = '#282B30'
PANEL2 = '#202226'
BORDER = '#414149'
RED = '#A21729'
RED_BRIGHT = '#CE3044'
RED_DARK = '#77101F'
FG = '#F3F0F1'
MUTED = '#B9B4BA'
GREEN = '#67C8A0'
YELLOW = '#E4BA79'
BAD = '#EB6870'

# Explicitly identify the two non-offline legacy utilities; we cannot pretend
# the AudD/ACRCloud backend can work without credentials.
LEGACY_MIXID = 'mix-id · benutzt bereits Shazam'


def all_local_tracks(root: Path):
    return C.audio_files(root)


def probe_database() -> str:
    if C.DB.is_file() and C.DB.stat().st_size > 100:
        try:
            manifest = json.loads((C.DATA/'bibliothek.json').read_text(encoding='utf-8'))
            count = manifest.get('file_count')
            return 'Bereit' + (f' · {count} Tracks' if count else '')
        except (OSError, ValueError):
            return 'Bereit · importiert'
    return 'Fehlt'


def probe_engine(cfg: dict) -> bool:
    return C.locate_source(cfg) is not None


def select_target_fragments(parts: list[Path], duration: float, confirmed: list[dict], factor: float) -> list[Path]:
    # Time of the transformed segment maps to original timeline by *factor.
    # Reduce work only for well-supported offline regions.
    intervals = [(max(0., x['first_detection'] - 25.),
                  min(duration, x['last_detection'] + 35.)) for x in confirmed
                 if x.get('score', 0) >= 200 or x.get('samples', 0) >= 2]
    if not intervals:
        return parts
    result = []
    for p in parts:
        m = C.SEGMENT_RE.search(p.name)
        if not m:
            continue
        midpoint = (int(m.group(1))*C.SEGMENT_SECONDS + C.SEGMENT_SECONDS/2)*factor
        if not any(left <= midpoint <= right for left, right in intervals):
            result.append(p)
    return result


def do_match(parts: list[Path], factor: float, kind: str, directory: Path, env: dict,
             cancel: threading.Event, log) -> tuple[list[C.OfflineHit], list[str]]:
    if not parts:
        return [], []
    flist = directory/'to_match.txt'
    C.write_utf8_list(flist, parts)
    command = [sys.executable, str(C.APP/'audfprint_utf8.py'), 'match',
               '--dbase', str(C.DB), '--exact-count', '--find-time-range',
               '--max-matches', '2', '--min-count', '25', '--list', str(flist)]
    code, output = C.run_cmd(command, env, cwd=C.VENDOR, cancel=cancel)
    if code:
        log(f'Warnung: Offline-Abgleich fehlgeschlagen ({kind} {factor:.2f}): {output[-250:]}')
        return [], [f'{kind} {factor:.2f}: {output[-500:]}']
    return C.parse_matches(output, factor, kind), []


def split_audio(mix: Path, directory: Path, cfg: dict, factor: float,
                kind: str, cancel: threading.Event):
    env = C.env_with_ffmpeg(cfg['ffmpeg_dir'])
    ffmpeg = shutil.which('ffmpeg', path=env['PATH'])
    if not ffmpeg:
        raise RuntimeError('FFmpeg fehlt. Bitte in Einstellungen die ffmpeg.exe auswählen.')
    directory.mkdir(parents=True, exist_ok=True)
    for f in directory.glob('part-*.wav'):
        f.unlink()
    if abs(factor-1.) < 1e-8:
        filter_args = []
    else:
        filter_args = ['-af', C.mode_args(kind, factor)]
    command = [ffmpeg, '-hide_banner', '-loglevel', 'error', '-y', '-i', str(mix),
               '-map', '0:a:0', '-vn', *filter_args,
               '-ac', '1', '-ar', '11025', '-c:a', 'pcm_s16le', '-f', 'segment',
               '-segment_time', str(C.SEGMENT_SECONDS), '-reset_timestamps', '1',
               str(directory/'part-%04d.wav')]
    code, output = C.run_cmd(command, env, cancel=cancel)
    if code:
        raise RuntimeError('FFmpeg konnte Set nicht aufteilen: ' + output[-800:])
    return [p for p in sorted(directory.glob('part-*.wav')) if p.stat().st_size > 20000]


def two_pass_offline(mix: Path, cfg: dict, duration: float, notify, cancel: threading.Event):
    """One normal-speed lookup, then speed-corrected lookups in remaining regions."""
    env = C.env_with_ffmpeg(cfg['ffmpeg_dir'])
    if not C.DB.exists():
        raise RuntimeError('Musikdatenbank fehlt. Bitte zuerst Datenbank aufbauen.')
    errors: list[str] = []
    hits: list[C.OfflineHit] = []
    with tempfile.TemporaryDirectory(prefix='set-scanner-v02-') as td:
        root = Path(td)
        notify('stage', 'A', 'running', 'Set aufteilen und Normaltempo prüfen')
        parts = split_audio(mix, root/'segments', cfg, 1., 'tempo', cancel)
        notify('progress', 'A', f'{len(parts)} Abschnitte · Originaltempo')
        first, e = do_match(parts, 1., 'tempo', root, env, cancel, lambda msg: notify('log', msg))
        hits += first
        errors += e
        quick, _ = C.grouped_hits(first, duration)
        notify('hits', quick)
        notify('stage', 'A', 'done', f'{len(quick)} Trefferkandidaten')
        if cancel.is_set():
            raise RuntimeError('Abgebrochen')
        notify('stage', 'B', 'running', 'Ungeklärte Abschnitte mit BPM-Korrektur')
        factors = [0.94, 1.06, 0.97, 1.03, 0.90, 1.10,
                   0.92, 1.08, 0.96, 1.04, 0.98, 1.02,
                   0.91, 1.09, 0.93, 1.07, 0.95, 1.05, 0.99, 1.01]
        modes = [('tempo', f) for f in factors]
        if cfg.get('tempo_pitch'):
            modes += [('pitch', f) for f in factors]
        # Avoid selecting areas covered by strong hits repeatedly; include all
        # remaining windows and keep cross-variant confirmation separate.
        for idx, (kind, factor) in enumerate(modes, 1):
            if cancel.is_set():
                raise RuntimeError('Abgebrochen')
            notify('progress', 'B', f'Variante {idx}/{len(modes)} · {kind} · {factor:.2f}')
            try:
                transformed = split_audio(mix, root/'segments', cfg, factor, kind, cancel)
                search_parts = select_target_fragments(transformed, duration, quick, factor)
                these, err = do_match(search_parts, factor, kind, root, env, cancel,
                                      lambda msg: notify('log', msg))
                hits += these
                errors += err
                if idx % 4 == 0:
                    all_ok, _ = C.grouped_hits(hits, duration)
                    notify('hits', all_ok)
                notify('log', f'Tiefenscan {idx}/{len(modes)}: {len(search_parts)} Fenster · {len(these)} Kandidaten')
            except Exception as exc:
                if cancel.is_set():
                    raise
                errors.append(f'{kind} {factor}: {exc}')
                notify('log', f'Tiefenscan: Variante {kind} {factor:.2f} fehlgeschlagen')
        accepted, rejected = C.grouped_hits(hits, duration)
        # Require a stronger single match than historic false positives.
        accepted2, weak2 = [], list(rejected)
        for hit in accepted:
            if hit['score'] >= 180 or (hit['score'] >= 75 and hit['samples'] >= 2):
                accepted2.append(hit)
            else:
                weak2.append(hit)
        accepted2.sort(key=lambda h: h['time'])
        notify('hits', accepted2)
        notify('stage', 'B', 'done', f'{len(accepted2)} Offline-Kandidaten insgesamt')
        return accepted2, weak2, errors


def format_report(mix: Path, duration: float, offline, weak, shazam, errors, cfg):
    """TXT plus optional machine-readable JSON. Timestamps are estimates."""
    output = C.final_report(mix, duration, offline, weak, shazam, errors, cfg)
    # Correct the older static methodology text: v0.2 first runs a normal pass.
    data = output.read_text(encoding='utf-8-sig')
    data += ('\nV0.2: Stufe A audfprint Originaltempo; Stufe B dasselbe audfprint '
             'mit Tempo-Varianten für unklare Stellen. '\
             'mix-id verwendet Shazam online und ist keine zweite Offline-Engine.\n')
    output.write_text(data, encoding='utf-8-sig')
    return output


# Only directly supported media hosts are accepted. No arbitrary URL fetching.
def media_provider(url: str) -> str | None:
    """Return a supported service name (not a guarantee a specific link will work)."""
    try:
        parsed = urlparse(url.strip())
        host = (parsed.hostname or '').lower().rstrip('.')
        if parsed.scheme not in ('http', 'https') or parsed.username or parsed.password:
            return None
        if host in ('youtu.be', 'youtube.com') or host.endswith('.youtube.com'):
            return 'YouTube'
        if host in ('soundcloud.com', 'on.soundcloud.com', 'soundcloud.app.goo.gl') or host.endswith('.soundcloud.com'):
            return 'SoundCloud'
        if host == 'mixcloud.com' or host.endswith('.mixcloud.com'):
            return 'Mixcloud'
    except (ValueError, TypeError):
        pass
    return None


def download_online(url: str, cfg: dict, cancel: threading.Event, log) -> Path:
    provider = media_provider(url)
    if not provider:
        raise RuntimeError('Bitte einen YouTube-, SoundCloud- oder Mixcloud-Link eingeben.')
    import yt_dlp  # noqa: F401; installed via requirements.txt
    from uuid import uuid4
    temp = C.APP/'Downloads_Online'/uuid4().hex[:10]
    temp.mkdir(parents=True, exist_ok=False)
    template = str(temp/'%(title).100s-%(id)s.%(ext)s')
    env = C.env_with_ffmpeg(cfg['ffmpeg_dir'])
    # --no-playlist: one set/track, never silently download a whole account/playlist.
    cmd = [sys.executable, '-m', 'yt_dlp', '--no-playlist', '--extract-audio',
           '--audio-format', 'mp3', '--no-progress', '--output', template, url]
    code, result = C.run_cmd(cmd, env, cancel=cancel, echo=True, log=log)
    if code != 0:
        raise RuntimeError(f'{provider}-Link konnte nicht geladen werden (Login, Sperre oder Format): ' + result[-800:])
    candidates = sorted(temp.glob('*.mp3'), key=lambda p: p.stat().st_mtime)
    if candidates:
        return candidates[-1]
    raise RuntimeError(f'{provider}-Download abgeschlossen, aber keine MP3 gefunden.')


class AppGUI:
    def __init__(self):
        for p in [C.DATA, C.OUTPUT, C.LOGS]:
            p.mkdir(parents=True, exist_ok=True)
        self.cfg = C.read_config()
        self.root = TkinterDnD.Tk() if DND_OK else tk.Tk()
        self.root.title('SET SCANNER v0.7  |  BLOOD RED · ALLES IM ORDNER')
        self.root.geometry('1150x840')
        self.root.minsize(980, 730)
        self.root.configure(bg=BG)
        self.events = queue.Queue()
        self.cancel = threading.Event()
        self.running = False
        self.library = tk.StringVar(value=self.cfg.get('library') or C.DEFAULT_LIBRARY)
        self.set_path = tk.StringVar(value='')
        self.media_url = tk.StringVar(value='')
        self.use_shazam = tk.BooleanVar(value=bool(self.cfg.get('shazam', True)))
        self.pitch = tk.BooleanVar(value=bool(self.cfg.get('tempo_pitch', False)))
        self.max_shazam = tk.StringVar(value=str(self.cfg.get('max_shazam', 50)))
        self.mixid_enabled = tk.BooleanVar(value=bool(self.cfg.get('mixid', True)))
        self.mixid_dir = tk.StringVar(value=self.cfg.get('mixid_dir',''))
        self.use_local_ai = tk.BooleanVar(value=bool(self.cfg.get('local_ai_review',False)))
        self.stats = tk.StringVar(value='Noch keine Treffer')
        self.stages = {}
        self.statuses = {}
        self.current_hits = {}
        self.settings_open = False
        self._ui()
        self.root.after(80, self._events)
        self.root.after(500, self._refresh_readiness)

    def _label(self, parent, text, size=10, bold=False, color=FG, bg=None):
        return tk.Label(parent, text=text, font=('Segoe UI', size, 'bold' if bold else 'normal'),
                        fg=color, bg=bg or parent.cget('bg'), anchor='w')

    def _button(self, parent, text, command, bg=RED, fg=FG, width=None):
        opts = dict(text=text, command=command, bg=bg, fg=fg, activebackground=RED_BRIGHT,
                    activeforeground=FG, relief='flat', bd=0, cursor='hand2',
                    font=('Segoe UI', 10, 'bold'), padx=14, pady=9)
        if width: opts['width']=width
        return tk.Button(parent, **opts)

    def _entry(self, parent, var, width=None):
        entry = tk.Entry(parent, textvariable=var, bg=PANEL2, fg=FG,
                         insertbackground=FG, relief='flat', bd=0,
                         highlightthickness=1, highlightbackground=BORDER,
                         highlightcolor=RED_BRIGHT, font=('Segoe UI', 10))
        if width: entry.configure(width=width)
        return entry

    def _ui(self):
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)
        header = tk.Frame(self.root, bg='#151618', padx=22, pady=14)
        header.grid(row=0, column=0, sticky='ew')
        self._label(header, 'SET  SCANNER', 23, True).pack(side='left')
        self._label(header, 'v0.7  /  OFFLINE + MIX-ID + SHAZAM', 10, True, RED_BRIGHT, '#151618').pack(side='left', padx=18, pady=(12,0))
        tk.Frame(self.root, bg=RED, height=3).grid(row=0, column=0, sticky='sew')
        main = tk.Frame(self.root, bg=BG, padx=20, pady=15)
        main.grid(row=1, column=0, sticky='nsew')
        main.columnconfigure(0, weight=3, minsize=570)
        main.columnconfigure(1, weight=2, minsize=330)
        main.rowconfigure(1, weight=1)
        left = tk.Frame(main, bg=BG)
        left.grid(row=0, column=0, rowspan=2, sticky='nsew', padx=(0,14))
        right = tk.Frame(main, bg=BG)
        right.grid(row=0, column=1, rowspan=2, sticky='nsew')

        self._label(left, '1  SET', 12, True).pack(anchor='w', pady=(0,7))
        drop = tk.Frame(left, bg=PANEL, highlightbackground=RED_DARK, highlightthickness=2, height=96)
        drop.pack(fill='x')
        drop.pack_propagate(False)
        self._label(drop, '↓   HIER REINZIEHEN', 17, True, FG, PANEL).pack(anchor='center', pady=(16,5))
        self._label(drop, 'MP3 · WAV · FLAC · AIFF', 10, False, MUTED, PANEL).pack(anchor='center')
        if DND_OK:
            drop.drop_target_register(DND_FILES)
            drop.dnd_bind('<<Drop>>', self._dropped)
            for child in drop.winfo_children():
                child.drop_target_register(DND_FILES)
                child.dnd_bind('<<Drop>>', self._dropped)
        else:
            self._label(left, 'Drag & Drop fehlt: tkinterdnd2 installieren; Durchsuchen funktioniert trotzdem.',
                        9, color=YELLOW).pack(anchor='w', pady=3)
        row = tk.Frame(left, bg=BG)
        row.pack(fill='x', pady=(6,12))
        self._entry(row, self.set_path).pack(side='left', fill='x', expand=True, ipady=8)
        self._button(row, 'DURCHSUCHEN', self.pick_set, bg=PANEL).pack(side='left', padx=(7,0))

        ytrow = tk.Frame(left, bg=BG)
        ytrow.pack(fill='x', pady=(0,8))
        self._label(ytrow, 'ODER LINK  ·  YOUTUBE / SOUNDCLOUD / MIXCLOUD', 10, True).pack(anchor='w', pady=(0,4))
        inp = tk.Frame(ytrow, bg=BG)
        inp.pack(fill='x')
        self._entry(inp, self.media_url).pack(side='left', fill='x', expand=True, ipady=8)
        self._button(inp, 'LINK LADEN', self.start_download, bg=PANEL).pack(side='left', padx=(7,0))

        self._label(left, '2  AUTOMATISCH ERKENNEN', 12, True).pack(anchor='w', pady=(12,7))
        self.start_button = self._button(left, '▶   SET SCANNEN', self.start_scan, bg=RED, width=26)
        self.start_button.pack(fill='x', ipady=11)
        controls = tk.Frame(left, bg=BG)
        controls.pack(fill='x', pady=(8,10))
        self.stop_button = self._button(controls, 'SCAN ABBRECHEN', self.stop, bg=PANEL)
        self.stop_button.pack(side='right')
        self.stop_button.configure(state='disabled')
        self._button(controls, 'ERGEBNISSE ÖFFNEN', lambda: self._open(C.OUTPUT), bg=PANEL).pack(side='left')
        self._button(controls, '⚙ EINSTELLUNGEN', self.toggle_settings, bg=PANEL).pack(side='left', padx=5)

        # Local text review is OPTIONAL and prominent on the main page.
        # It is not a music-recognition stage.
        ki_panel = tk.Frame(left, bg=PANEL, padx=12, pady=9,
                            highlightbackground=RED_DARK, highlightthickness=1)
        ki_panel.pack(fill='x', pady=(2,10))
        self._label(ki_panel, 'LOKALE KI  ·  OPTIONAL', 10, True, RED_BRIGHT, PANEL).pack(anchor='w')
        self._label(ki_panel, 'Prüft die fertige TXT-Tracklist auf Widersprüche. Erkennt KEINE Songs.',
                    9, color=MUTED, bg=PANEL).pack(anchor='w', pady=(2,5))
        ki_buttons = tk.Frame(ki_panel, bg=PANEL)
        ki_buttons.pack(fill='x')
        self._button(ki_buttons, 'LM STUDIO INSTALLIEREN', self.install_local_ai,
                     bg=RED_DARK).pack(side='left', padx=(0,5))
        self._button(ki_buttons, 'OLLAMA', self.install_ollama,
                     bg=PANEL2).pack(side='left', padx=(0,5))
        self._button(ki_buttons, 'VERBINDUNG TESTEN', self.check_local_ai,
                     bg=PANEL2).pack(side='left')
        self.ai_status_text = tk.StringVar(value='KI: nicht geprüft · für Scanner nicht erforderlich')
        tk.Label(ki_panel, textvariable=self.ai_status_text, bg=PANEL, fg=MUTED,
                 font=('Segoe UI',9), anchor='w').pack(anchor='w', pady=(5,0))
        self._check(ki_panel, 'Nach dem Scan TXT zusätzlich lokal prüfen', self.use_local_ai).pack(anchor='w', pady=(4,0))

        self.settings_window=tk.Toplevel(self.root)
        self.settings_window.title('SET SCANNER · Einstellungen & Engines')
        self.settings_window.configure(bg=PANEL)
        self.settings_window.geometry('720x850')
        self.settings_window.minsize(620,800)
        self.settings_window.protocol('WM_DELETE_WINDOW',self.toggle_settings)
        self.settings = tk.Frame(self.settings_window, bg=PANEL, padx=20, pady=16)
        self.settings.pack(fill='both',expand=True)
        self.settings_window.withdraw()
        liblabel = self._label(self.settings, 'MUSIKDATENBANK  ·  Einmalig vorbereiten', 10, True, bg=PANEL)
        liblabel.pack(anchor='w')
        librow = tk.Frame(self.settings, bg=PANEL)
        librow.pack(fill='x', pady=(5,8))
        self._entry(librow,self.library).pack(side='left',fill='x',expand=True,ipady=6)
        self._button(librow, '...', self.pick_library, bg=PANEL2).pack(side='left',padx=4)
        self.index_button = self._button(self.settings, 'DATENBANK AUFBAUEN / ERNEUERN', self.start_index, bg=RED_DARK)
        self.index_button.pack(fill='x', pady=(0,5))
        self._button(self.settings, 'Vorhandene .pklz-Datenbank importieren', self.import_db, bg=PANEL2).pack(fill='x')
        trow = tk.Frame(self.settings,bg=PANEL)
        trow.pack(fill='x',pady=7)
        self._check(trow,'Shazam für Rest-Lücken', self.use_shazam).pack(anchor='w')
        self._check(trow,'Auch Tempoänderungen ohne Key Lock prüfen (langsamer)',self.pitch).pack(anchor='w')
        opt = tk.Frame(self.settings,bg=PANEL)
        opt.pack(fill='x')
        self._label(opt,'Max. Shazam-Anfragen:', 9,bg=PANEL).pack(side='left')
        tk.Spinbox(opt, from_=0, to=250, width=5, textvariable=self.max_shazam,
                   bg=PANEL2, fg=FG, buttonbackground=PANEL2, relief='flat').pack(side='left', padx=7)
        self._label(self.settings,'ORIGINAL-PROGRAMM (IM SCANNER INTEGRIERT)',10,True,bg=PANEL).pack(anchor='w',pady=(12,4))
        self._check(self.settings,'mix-id (Original-Tool, Shazam-basiert)',self.mixid_enabled).pack(anchor='w')
        self._label(self.settings,'LOKALE KI · OPTIONAL, NUR TEXTPRÜFUNG',10,True,bg=PANEL).pack(anchor='w',pady=(8,4))
        self._check(self.settings,'Ergebnis-TXT lokal auf Widersprüche prüfen (keine Audio-ID)',self.use_local_ai).pack(anchor='w')
        kirow=tk.Frame(self.settings,bg=PANEL)
        kirow.pack(fill='x',pady=(3,2))
        self._button(kirow,'LM STUDIO HERUNTERLADEN',self.install_local_ai,bg=RED_DARK).pack(side='left',expand=True,fill='x',padx=(0,4))
        self._button(kirow,'KI-VERBINDUNG PRÜFEN',self.check_local_ai,bg=PANEL2).pack(side='left',expand=True,fill='x')
        self._button(self.settings,'ALTERNATIVE: OLLAMA HERUNTERLADEN',self.install_ollama,bg=PANEL2).pack(fill='x',pady=(3,0))
        self._label(self.settings,'Lokales Modell z.B. Qwen3 14B. Ein Modell muss im LM Studio geladen sein.',9,color=MUTED,bg=PANEL).pack(anchor='w')

        self._label(left, 'LIVE-TREFFER  ·  Schätzwerte, bitte nachhören', 11, True).pack(anchor='w', pady=(15,5))
        table_frame = tk.Frame(left,bg=PANEL2)
        table_frame.pack(fill='both',expand=True)
        style=ttk.Style(self.root)
        if 'clam' in style.theme_names(): style.theme_use('clam')
        style.configure('Dark.Treeview', background=PANEL2, foreground=FG,
                        fieldbackground=PANEL2, bordercolor=BORDER, rowheight=25,
                        font=('Segoe UI',9))
        style.configure('Dark.Treeview.Heading', background=PANEL, foreground=FG, font=('Segoe UI',9,'bold'))
        style.map('Dark.Treeview', background=[('selected',RED_DARK)])
        self.result_table = ttk.Treeview(table_frame,columns=('time','title','source'),
                                         show='headings',style='Dark.Treeview',height=7)
        for col,text,width in [('time','ZEIT',100),('title','TRACK',360),('source','QUELLE',92)]:
            self.result_table.heading(col,text=text)
            self.result_table.column(col,width=width,anchor='w',stretch=col=='title')
        self.result_table.pack(fill='both',expand=True)
        self._label(left, 'Anzeige wird während des Scans aktualisiert; endgültige Tracklist in TXT.',9,color=MUTED).pack(anchor='w',pady=4)

        self._label(right, 'STATUS  /  VORAUSSETZUNGEN', 12, True).pack(anchor='w',pady=(0,7))
        readiness=tk.Frame(right,bg=PANEL,padx=12,pady=10)
        readiness.pack(fill='x')
        for key,desc in [('set','DJ-Set'),('ffmpeg','FFmpeg'),('db','Musikdatenbank'),
                         ('offline','Offline-Engine'),('mixid','mix-id'),('shazam','ShazamIO')]:
            row=tk.Frame(readiness,bg=PANEL)
            row.pack(fill='x',pady=3)
            icon=self._label(row,'○',13,True,MUTED,PANEL)
            icon.pack(side='left')
            self._label(row,desc,10,True,bg=PANEL).pack(side='left',padx=(7,0))
            txt=self._label(row,'Prüfen …',9,False,MUTED,PANEL)
            txt.pack(side='right')
            self.statuses[key]=(icon,txt)

        self._label(right, 'SCAN-ABLAUF',12,True).pack(anchor='w',pady=(17,7))
        phase=tk.Frame(right,bg=PANEL,padx=11,pady=10)
        phase.pack(fill='x')
        for key,desc in [('setup','0 · Dateien vorbereiten'),('A','1 · Schnellscan offline'),
                         ('B','2 · Tiefenscan offline + Tempo'),('M','3 · mix-id (Original)'),
                         ('S','4 · Shazam für Lücken'),
                         ('E','5 · TXT-Ergebnis speichern')]:
            row=tk.Frame(phase,bg=PANEL)
            row.pack(fill='x',pady=4)
            icon=self._label(row,'○',15,True,MUTED,PANEL)
            icon.pack(side='left')
            texts=tk.Frame(row,bg=PANEL)
            texts.pack(side='left',fill='x',expand=True,padx=8)
            title=self._label(texts,desc,10,True,bg=PANEL)
            title.pack(anchor='w')
            sub=self._label(texts,'Wartet',9,False,MUTED,PANEL)
            sub.pack(anchor='w')
            self.stages[key]=(icon,sub)
        self._label(right, 'FORTSCHRITT / PROTOKOLL', 11, True).pack(anchor='w',pady=(17,6))
        self.progress = tk.StringVar(value='Bereit für den ersten Scan')
        tk.Label(right,textvariable=self.progress,bg=BG,fg=MUTED,anchor='w',wraplength=380,
                 font=('Segoe UI',9)).pack(anchor='w',pady=(0,5))
        self.logbox=scrolledtext.ScrolledText(right,height=6,wrap='word',bg='#151719',fg='#D4D0D3',
                                              insertbackground=FG,relief='flat',font=('Consolas',9))
        self.logbox.pack(fill='both',expand=True)
        self.logbox.configure(state='disabled')
        self._label(right,'mix-id + ShazamIO nutzen beide Shazam online · Offline bleibt audfprint',9,color=YELLOW).pack(anchor='w',pady=(7,0))

    def _check(self,parent,text,var):
        return tk.Checkbutton(parent,text=text,variable=var,bg=PANEL,fg=FG,selectcolor=PANEL2,
                              activebackground=PANEL,activeforeground=FG,font=('Segoe UI',9),anchor='w')

    def toggle_settings(self):
        self.settings_open=not self.settings_open
        if self.settings_open:
            self.settings_window.deiconify()
            self.settings_window.lift()
            self.settings_window.focus_force()
        else:
            self.settings_window.withdraw()

    def _dropped(self,event):
        candidates=self.root.tk.splitlist(event.data)
        if candidates:
            name=str(candidates[0]).strip()
            if Path(name).is_file() and Path(name).suffix.lower() in C.EXTS:
                self.set_path.set(name)
            else:
                messagebox.showwarning('SET SCANNER','Bitte eine Audiodatei ablegen.')
            self._refresh_readiness()

    def _stage(self,key,state,detail=''):
        self.events.put(('stage',key,state,detail))

    def _notify(self,kind,*args):
        self.events.put((kind,*args))

    def _stage_ui(self,key,state,detail):
        icon,sub=self.stages[key]
        color={'done':GREEN,'running':RED_BRIGHT,'failed':BAD,'skipped':YELLOW,'waiting':MUTED}.get(state,MUTED)
        sym={'done':'✓','running':'◉','failed':'✕','skipped':'–','waiting':'○'}.get(state,'○')
        icon.configure(text=sym,fg=color)
        sub.configure(text=detail or state,fg=color if state!='waiting' else MUTED)

    def _events(self):
        try:
            while True:
                event=self.events.get_nowait()
                kind=event[0]
                if kind=='stage':
                    self._stage_ui(*event[1:])
                elif kind=='progress':
                    _,phase,msg=event
                    self.progress.set(msg)
                    if phase in self.stages:
                        self.stages[phase][1].configure(text=msg)
                elif kind=='log':
                    self.logbox.configure(state='normal')
                    self.logbox.insert('end',str(event[1])+'\n')
                    self.logbox.see('end')
                    self.logbox.configure(state='disabled')
                elif kind=='hits':
                    self._render_hits(event[1])
                elif kind=='ai_status':
                    self.ai_status_text.set('KI: '+str(event[1]))
                    messagebox.showinfo('Lokale KI · Status',str(event[1]))
                elif kind=='set_path':
                    self.set_path.set(str(event[1]))
                elif kind=='done':
                    self._running(False)
                    self._refresh_readiness()
                    messagebox.showinfo('SET SCANNER',str(event[1]))
                elif kind=='error':
                    self._running(False)
                    self._refresh_readiness()
                    messagebox.showerror('SET SCANNER',str(event[1]))
        except queue.Empty:
            pass
        self.root.after(100,self._events)

    def _render_hits(self,hits):
        for rec in hits:
            k=('off',rec.get('full_path'),int(float(rec['time'])/20)) if rec.get('source')=='offline' else (
                rec.get('source'),rec.get('artist'),rec.get('title'),int(rec.get('time',0)/20))
            self.current_hits[k]=rec
        for item in self.result_table.get_children():
            self.result_table.delete(item)
        for hit in sorted(self.current_hits.values(),key=lambda r:r.get('time',0))[:200]:
            if hit.get('source')=='offline':
                method='Offline ' + ('B' if abs(hit.get('factor',1.)-1)>0.001 else 'A')
                name=hit['title']
            else:
                method=hit.get('source','Shazam')
                name=f"{hit.get('artist','')} – {hit.get('title','')}"
            self.result_table.insert('', 'end', values=(C.hhmmss(hit.get('time',0)),name[:90],method))
        self.stats.set(f'{len(self.current_hits)} Kandidaten')

    def _running(self,state):
        self.running=state
        self.start_button.configure(state='disabled' if state else 'normal')
        self.index_button.configure(state='disabled' if state else 'normal')
        self.stop_button.configure(state='normal' if state else 'disabled')

    def _refresh_readiness(self):
        try:
            f=C.locate_ffmpeg(self.cfg)
            checks={
                'set':(Path(self.set_path.get()).is_file(),'Geladen' if Path(self.set_path.get()).is_file() else 'Fehlt'),
                'ffmpeg':(bool(f),'Bereit' if f else 'Fehlt'),
                'db':(C.DB.is_file(),probe_database()),
                'offline':(probe_engine(self.cfg),'Bereit' if probe_engine(self.cfg) else 'Quelle fehlt'),
                'mixid':(X.mixid_ready({**self.cfg,'mixid_dir':self.mixid_dir.get()}),
                         'Bereit' if X.mixid_ready({**self.cfg,'mixid_dir':self.mixid_dir.get()}) else 'Nicht eingerichtet'),
                'shazam':(importlib.util.find_spec('shazamio') is not None,'Bereit' if self.use_shazam.get() else 'Optional aus')
            }
            if f:
                self.cfg['ffmpeg_dir']=f
            for key,(ready,detail) in checks.items():
                icon,txt=self.statuses[key]
                if (key=='shazam' and not self.use_shazam.get()) or (key=='mixid' and not self.mixid_enabled.get()):
                    icon.configure(text='–',fg=YELLOW)
                    txt.configure(text='Deaktiviert',fg=YELLOW)
                else:
                    icon.configure(text='✓' if ready else '✕',fg=GREEN if ready else BAD)
                    txt.configure(text=detail[:23],fg=GREEN if ready else BAD)
        finally:
            self.root.after(2400,self._refresh_readiness)

    def install_local_ai(self):
        """Open verified official download; user chooses and installs it."""
        webbrowser.open('https://lmstudio.ai/download?os=windows')
        messagebox.showinfo('Lokale KI einrichten',
            '1. LM Studio für Windows installieren.\n'
            '2. In LM Studio Qwen3 14B (4-bit/GGUF) suchen und herunterladen.\n'
            '3. Modell laden und lokalen Server einschalten (Port 1234).\n'
            '4. Hier auf KI-VERBINDUNG PRÜFEN klicken.\n\n'
            'WICHTIG: Das Modell erkennt keine Musik. Es prüft ausschließlich den Trefferbericht.')

    def install_ollama(self):
        webbrowser.open('https://ollama.com/download/windows')

    def check_local_ai(self):
        def worker():
            provider,model,status=L.detect()
            self.events.put(('ai_status',status))
        threading.Thread(target=worker,daemon=True).start()

    def pick_set(self):
        filename=filedialog.askopenfilename(title='Dein fertiges DJ-Set',filetypes=[
            ('DJ-Sets','*.mp3 *.wav *.flac *.aiff *.aif *.m4a *.ogg'),('Alle Dateien','*.*')])
        if filename:
            self.set_path.set(filename)
            self._refresh_readiness()

    def pick_library(self):
        folder=filedialog.askdirectory(title='Eigene Musikbibliothek auswählen',
                                       initialdir=self.library.get() if Path(self.library.get()).is_dir() else str(Path.home()))
        if folder:self.library.set(folder)

    def pick_ffmpeg(self):
        file=filedialog.askopenfilename(title='ffmpeg.exe auswählen',filetypes=[('FFmpeg','ffmpeg.exe'),('EXE','*.exe')])
        if file:
            self.cfg['ffmpeg_dir']=str(Path(file).parent)
            C.save_config(self.cfg)
            self._notify('log','FFmpeg: '+str(Path(file).parent))
            self._refresh_readiness()

    def pick_audfprint(self):
        folder=filedialog.askdirectory(title='Ordner mit audfprint.py auswählen')
        if folder:
            self.cfg['audfprint_source']=folder
            C.save_config(self.cfg)
            self._refresh_readiness()

    def pick_mixid(self):
        folder=filedialog.askdirectory(title='mix-id-Ordner wählen (cli.mjs + lib/audio.mjs)')
        if folder:
            self.mixid_dir.set(folder)
            self.cfg['mixid_dir']=folder
            C.save_config(self.cfg)
            self._refresh_readiness()

    def import_db(self):
        filename=filedialog.askopenfilename(title='Vorhandene audfprint-Datenbank (.pklz)',
                                             filetypes=[('audfprint Datenbank','*.pklz')])
        if not filename:return
        if C.DB.exists() and not messagebox.askyesno('Import','Vorhandene SET SCANNER-Datenbank ersetzen?'):
            return
        C.DATA.mkdir(parents=True,exist_ok=True)
        shutil.copy2(filename,C.DB)
        (C.DATA/'bibliothek.json').write_text(json.dumps({'source':'importiert','created':C.stamp()}),encoding='utf-8')
        self._notify('log','Datenbank importiert: '+filename)
        self._refresh_readiness()

    def _settings_cfg(self):
        try: limit=int(self.max_shazam.get())
        except ValueError: raise RuntimeError('Shazam-Limit muss eine Zahl sein.')
        base={k:v for k,v in self.cfg.items()
              if k not in {'trackid','trackid_exe','trackid_try_sandbox',
                           'trackid_backend','max_trackid'}}
        cfg={**base,'library':self.library.get().strip(),
             'shazam':self.use_shazam.get(),
             'tempo_pitch':self.pitch.get(),
             'max_shazam':max(0,min(limit,250)),
             'mixid':self.mixid_enabled.get(),
             'mixid_dir':self.mixid_dir.get(),
             'local_ai_review':self.use_local_ai.get()}
        ff=C.locate_ffmpeg(cfg)
        if not ff:raise RuntimeError('FFmpeg fehlt. Bitte unter Einstellungen auswählen.')
        cfg['ffmpeg_dir']=ff
        self.cfg=cfg
        C.save_config(cfg)
        return cfg

    def _launch(self,job):
        if self.running:return
        try:cfg=self._settings_cfg()
        except Exception as exc:
            messagebox.showerror('SET SCANNER',str(exc))
            return
        self.cancel.clear()
        self._running(True)
        def worker():
            try:
                msg=job(cfg)
                self.events.put(('done',msg))
            except Exception as exc:
                C.LOGS.mkdir(parents=True,exist_ok=True)
                (C.LOGS/'letzter_fehler.txt').write_text(traceback.format_exc(),encoding='utf-8')
                self.events.put(('error',f'{exc}\n\nDetails: {C.LOGS/"letzter_fehler.txt"}'))
        threading.Thread(target=worker,daemon=True).start()

    def start_index(self):
        if C.DB.exists() and not messagebox.askyesno('Datenbank','Vorhandene Datenbank wirklich neu erstellen?'):
            return
        def job(cfg):
            self._notify('log','Datenbank wird indexiert …')
            C.build_database(cfg,lambda msg:self._notify('log',msg),self.cancel)
            return 'Datenbank fertig! Jetzt DJ-Set auswählen und SET SCANNEN klicken.'
        self._launch(job)

    def start_download(self):
        link=self.media_url.get().strip()
        if not media_provider(link):
            messagebox.showwarning('Link','Bitte einen gültigen YouTube-, SoundCloud- oder Mixcloud-Link eingeben.')
            return
        if not messagebox.askyesno('Online-Link','Hast du die Berechtigung, dieses Set herunterzuladen?'):
            return
        def job(cfg):
            self._notify('stage','setup','running','Online-Audio wird geladen')
            file=download_online(link,cfg,self.cancel,lambda msg:self._notify('log',msg))
            self.events.put(('set_path',str(file)))
            self._notify('stage','setup','done','Online-Audio geladen')
            return f'Datei gespeichert: {file}\nJetzt SET SCANNEN starten.'
        self._launch(job)

    def start_scan(self):
        path=Path(self.set_path.get().strip())
        if not path.is_file():
            self.pick_set()
            path=Path(self.set_path.get().strip())
        if not path.is_file():return
        if not C.DB.is_file():
            messagebox.showwarning('Datenbank fehlt', 'Bitte erst unter Einstellungen eine lokale Musikdatenbank erstellen oder importieren.')
            self.toggle_settings() if not self.settings_open else None
            return
        self.current_hits.clear()
        for item in self.result_table.get_children():self.result_table.delete(item)
        for key in self.stages:self._stage_ui(key,'waiting','Wartet')
        def job(cfg):
            C.install_engine(cfg,lambda msg:self._notify('log',msg))
            env=C.env_with_ffmpeg(cfg['ffmpeg_dir'])
            self._notify('stage','setup','running','Set-Länge und Dateien prüfen')
            duration=C.get_duration(path,env)
            self._notify('log',f'{path.name} | Dauer: {C.hhmmss(duration)}')
            self._notify('stage','setup','done','Datei bereit · '+C.hhmmss(duration))
            offline,weak,errors=two_pass_offline(path,cfg,duration,self._notify,self.cancel)
            engine_status={'Offline':'2 audfprint-Durchläufe abgeschlossen'}
            mix_hits=[]
            if cfg.get('mixid',True):
                self._notify('stage','M','running','Original-mix-id scannt über Shazam')
                try:
                    mix_hits,warn=X.run_mixid(path,cfg,env,lambda msg:self._notify('log','mix-id: '+msg),self.cancel)
                    if warn:
                        errors.append(warn)
                        self._notify('stage','M','failed',warn[:45])
                        engine_status['mix-id']='WARNUNG: '+warn
                    else:
                        self._notify('stage','M','done',f'{len(mix_hits)} Treffer')
                        engine_status['mix-id']=f'{len(mix_hits)} Treffer'
                    self._notify('hits',mix_hits)
                except Exception as exc:
                    if self.cancel.is_set():raise
                    errors.append('mix-id: '+str(exc))
                    engine_status['mix-id']='Fehler: '+str(exc)
                    self._notify('stage','M','failed',str(exc)[:48])
            else:
                engine_status['mix-id']='Deaktiviert'
                self._notify('stage','M','skipped','Deaktiviert')
            sha=[]
            if cfg.get('shazam') and cfg.get('max_shazam'):
                known=list(offline)
                for r in mix_hits:
                    known.append({'first_detection':r['time'],'last_detection':r['time']})
                times=C.unknown_probe_times(duration,known,cfg['max_shazam'])
                self._notify('stage','S','running',f'{len(times)} noch offene Proben')
                if times:
                    sha,e=asyncio.run(C.shazam_probes(path,times,cfg,
                                        lambda msg:self._notify('log',msg),self.cancel))
                    errors+=e
                self._notify('hits',[{**item,'source':'ShazamIO'} for item in C.consolidate_shazam(sha)])
                engine_status['ShazamIO']=f'{len(sha)} Beobachtungen'
                self._notify('stage','S','done',f'{len(sha)} Shazam-Beobachtungen')
            else:
                engine_status['ShazamIO']='Deaktiviert'
                self._notify('stage','S','skipped','Deaktiviert')
            self._notify('stage','E','running','Gemeinsame TXT-Tracklist speichern')
            report,merged=X.merged_report(path,duration,offline,weak,mix_hits,sha,engine_status,errors)
            self._notify('stage','E','done',report.name)
            self._notify('log','Gemeinsame TXT gespeichert: '+str(report))
            if cfg.get('local_ai_review'):
                self._notify('log','Lokale KI-Nachprüfung des TXT-Berichts (keine Musikerkennung) ...')
                try:
                    ai_out=L.review_report(report)
                    self._notify('log','KI-Hinweise separat gespeichert: '+str(ai_out))
                except Exception as exc:
                    self._notify('log','Lokale KI optional übersprungen: '+str(exc))
            return (f'Scan abgeschlossen.\nOffline: {len(offline)} Kandidaten'
                    f'\nmix-id: {len(mix_hits)} Treffer'
                    f'\nShazamIO: {len(sha)} Beobachtungen\nTXT: {report}')
        self._launch(job)

    def stop(self):
        self.cancel.set()
        self._notify('log','Abbruch angefordert')

    def _open(self,path):
        path.mkdir(exist_ok=True,parents=True)
        if os.name=='nt':os.startfile(str(path))
        else:messagebox.showinfo('SET SCANNER',str(path))

    def run(self):
        self.root.mainloop()


if __name__=='__main__':
    AppGUI().run()
